"""Validate same-peer repeated device events and original request retirement."""
import json,pathlib,struct,sys
p=pathlib.Path(sys.argv[1]);events=[json.loads(l) for l in (p/'wire.jsonl').read_text().splitlines()]
pending={};connect=[];disconnect=[];original_in=None;cancelled=[]
for index,e in enumerate(events):
 raw=bytes.fromhex(e['wire_hex']);kind,length=struct.unpack_from('<II',raw);header=len(raw)-length
 assert header in (12,16) and kind==e['type'];body=raw[header:]
 if e['direction']=='device-to-qemu' and kind==1:
  assert body==struct.pack('<BBBBHHH',1,2,0,0,0xffff,0xf117,0x0100);connect.append(index)
 if e['direction']=='device-to-qemu' and kind==2:assert not body;disconnect.append(index)
 if e['direction']=='qemu-to-device' and kind in (100,101):
  assert not disconnect,'new Host control/bulk after original disconnect'
  assert e['id'] not in pending;pending[e['id']]=(kind,body)
  if kind==101 and body[0]==129:
   assert original_in is None;original_in=e['id'];assert struct.unpack_from('<BBHIH',body)==(129,0,64,0,0)
 elif e['direction']=='device-to-qemu' and kind in (100,101):
  request_kind,request=pending.pop(e['id']);assert request_kind==kind
  if kind==101 and e['id']==original_in:
   assert body[0]==129 and body[1]==1 and struct.unpack_from('<H',body,2)[0]==0
 if e['direction']=='qemu-to-device' and kind==21:
  assert e['id']==original_in and not body;cancelled.append(e['id'])
assert not pending and original_in is not None and cancelled==[original_in]
assert len(connect)==len(disconnect)==3
assert connect[0]<disconnect[0]<connect[1]<disconnect[1]<connect[2]<disconnect[2]
log=(p/'device.log').read_text().splitlines();stop=log.index('BOUND_GUEST_STOP_OBSERVED')
assert all(log.index(f'REPEATED_DEVICE_{event}_SENT {cycle}')>stop for cycle in range(2) for event in ['CONNECT','DISCONNECT'])
assert log.count('REPEATED_DEVICE_EVENTS_DONE')==1
assert all(e['type']==21 for e in events[disconnect[0]+1:] if e['direction']=='qemu-to-device')
print(json.dumps(dict(original_in=original_in,original_in_cancelled=True,post_stop_reconnects=2,post_stop_disconnects=2,host_control_or_bulk_after_initial_disconnect=0,implicit_rebind_observed=False)))
