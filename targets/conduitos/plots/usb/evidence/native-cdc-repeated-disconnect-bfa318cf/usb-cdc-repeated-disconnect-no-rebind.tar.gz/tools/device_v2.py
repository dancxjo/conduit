"""Bounded external DEVICE events, same USBredir peer/guest/port, no Host driver."""
import argparse,pathlib,sys,time,threading
p=argparse.ArgumentParser(add_help=False);p.add_argument('--guest-serial',type=pathlib.Path,required=True);p.add_argument('--observer-deadline',type=pathlib.Path,required=True)
a,rest=p.parse_known_args();sys.argv=[sys.argv[0]]+rest
fixture=pathlib.Path(__file__).resolve().parent.parent/'usb-serial-product-faults/device.py'
text=fixture.read_text()
needle='            self.connected=False'
assert text.count(needle)==1
replacement='''            self.connected=False
            print('INITIAL_DEVICE_DISCONNECT_SENT',flush=True)
            def repeated():
                limit=float(observer_deadline.read_text())
                while time.monotonic()<limit:
                    raw=guest_serial.read_bytes() if guest_serial.exists() else b''
                    if any(line.startswith(b'CONDUIT_PROTOCOL_PLAY_STOPPED ') for line in raw.splitlines()):
                        print('BOUND_GUEST_STOP_OBSERVED',flush=True)
                        if limit-time.monotonic()<1.2:
                            print('REPEATED_DEVICE_EVENTS_REFUSED insufficient-absolute-window',flush=True)
                            return
                        for cycle in range(2):
                            time.sleep(.2)
                            self.metadata()
                            self.send(1,0,module.struct.pack('<BBBBHHH',1,2,0,0,0xffff,0xf117,0x0100))
                            self.connected=True
                            print('REPEATED_DEVICE_CONNECT_SENT '+str(cycle),flush=True)
                            time.sleep(.2)
                            self.send(2,0)
                            self.connected=False
                            print('REPEATED_DEVICE_DISCONNECT_SENT '+str(cycle),flush=True)
                        print('REPEATED_DEVICE_EVENTS_DONE',flush=True)
                        return
                    time.sleep(.01)
                print('REPEATED_DEVICE_EVENTS_REFUSED no-bound-stop',flush=True)
            threading.Thread(target=repeated,daemon=True).start()'''
# Serialize actual complete frames/record writes if the peer sends an unrelated
# control/cancel while the bounded event thread publishes metadata.
lock=threading.Lock()
namespace={'__name__':'__main__','__file__':str(fixture),'time':time,'threading':threading,'guest_serial':a.guest_serial.resolve(),'observer_deadline':a.observer_deadline.resolve()}
# This lock wraps the pre-existing send implementation inside the fault wrapper.
text=text.replace("    return original_send(self,kind,packet_id,body)","    with send_lock:\n        return original_send(self,kind,packet_id,body)")
namespace['send_lock']=lock
exec(compile(text.replace(needle,replacement),str(fixture),'exec'),namespace)
