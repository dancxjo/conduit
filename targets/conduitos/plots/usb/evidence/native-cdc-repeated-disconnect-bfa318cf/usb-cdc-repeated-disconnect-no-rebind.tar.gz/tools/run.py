"""Prepared, not executed: bounded x86 native CDC cancellation observation."""
import argparse, hashlib, json, pathlib, subprocess, tempfile, time
base=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--media',type=pathlib.Path,required=True)
p.add_argument('--output',type=pathlib.Path,required=True)
p.add_argument('--build-record',type=pathlib.Path,required=True)
p.add_argument('--expected-commit',required=True)
p.add_argument('--expected-package-sha256',required=True)
p.add_argument('--mode',choices=['disconnect-in'],required=True)
a=p.parse_args()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
media=a.media.resolve(); image=media/'conduitos.iso'
r=json.loads((media/'protocol-receipt.json').read_text()); build=json.loads(a.build_record.read_text())
assert build['schema']=='conduit.conduitos.build/v2' and build['artifact_role']=='product-host'
assert r['architecture']==build['architecture']=='x86_64'
assert build['base_commit']==a.expected_commit and build['elf_sha256']==r['kernel_sha256']
assert sha(media/'iso-root/boot/conduitos')==build['elf_sha256'] and sha(image)==r['image_sha256']
assert sha(media/'iso-root/boot/conduit-protocol-source.json')==a.expected_package_sha256
root_path=media/'iso-root/boot/conduit-protocol-root.json'; root=json.loads(root_path.read_text())
assert sha(root_path)==r['root_request_sha256'] and root['package_sha256']==a.expected_package_sha256
assert root['entry']=='cdc-serial-duplex-demonstration' and root['root_port']==1
assert root['attachment_epoch']==1 and root['maximum_control_operations']==5
assert root['endpoint_read']==dict(address=129,transfer_type=2,maximum_packet=64,interval=0,endpoint_epoch=1,maximum_operations=16)
assert root['endpoint_write']==dict(address=2,transfer_type=2,maximum_packet=64,interval=0,endpoint_epoch=1,maximum_operations=16)
assert root['preflight']['entry']=='cdc-serial-profile-preflight'
assert root['preflight']['maximum_discovery_operations']==2
assert r['root_kind']=='usb' and r['root_module_command']=='conduit.protocol/usb-root-request@1'
assert 1<=root['maximum_steps']<=1000000
out=a.output.resolve();out.mkdir();device=qemu=None
with tempfile.TemporaryDirectory(prefix='cdc-retirement-') as tmp:
 socket=pathlib.Path(tmp)/'device.sock'
 with (out/'device.log').open('x') as dl,(out/'qemu.log').open('x') as ql:
  try:
   command=['python3',str(base/'device.py'),'--guest-serial',str(out/'serial.log'),'--fault-mode',a.mode,'--socket',str(socket),'--transcript',str(out/'wire.jsonl'),'--seconds','65']
   device=subprocess.Popen(command,stdout=dl,stderr=dl)
   deadline=time.monotonic()+5
   while not socket.exists() and time.monotonic()<deadline:
    if device.poll() is not None:raise RuntimeError('fixture exited before socket')
    time.sleep(.02)
   if not socket.exists():raise RuntimeError('fixture socket absent')
   emulator=pathlib.Path('/usr/bin/qemu-system-x86_64').resolve()
   version=subprocess.run([str(emulator),'--version'],check=True,capture_output=True,text=True,timeout=5).stdout.splitlines()[0]
   assert 'version 10.2.1 ' in version
   argv=[str(emulator),'-M','q35','-cpu','max','-m','512M','-smp','1','-display','none','-vga','std','-monitor','none','-serial',f'file:{out}/serial.log','-no-reboot','-net','none','-cdrom',str(image),'-boot','d','-device','qemu-xhci,id=protocol-usb,p2=1,p3=0','-chardev',f'socket,id=cdc,path={socket}','-device','usb-redir,chardev=cdc,bus=protocol-usb.0,port=1,msos-desc=off,streams=off,debug=4']
   qemu=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=ql)
   started=time.monotonic();deadline=started+55;terminal_at=None;raw=b''
   while time.monotonic()<deadline:
    path=out/'serial.log';raw=path.read_bytes() if path.exists() else b''
    for path in [out/'serial.log',out/'device.log',out/'qemu.log',out/'wire.jsonl']:
     if path.exists() and path.stat().st_size>1048576:raise RuntimeError('bounded transcript exceeded')
    # Normal Kernel retirement after typed provider-loss is permitted.
    if (b'CONDUIT_PROTOCOL_REFUSAL ' in raw or b'CONDUIT_PROTOCOL_RETIRED complete' in raw) and terminal_at is None:terminal_at=time.monotonic()
    # Keep the SAME owned guest alive five seconds after Root outcome. The
    # original 55-second deadline never restarts; no retries or second guest.
    if terminal_at is not None and time.monotonic()-terminal_at>=5:break
    if qemu.poll() is not None:raise RuntimeError('guest exited before bounded post-stop observation')
    time.sleep(.02)
   text=raw.decode('utf8',errors='strict');device_text=(out/'device.log').read_text()
   markers={name:[line for line in text.splitlines() if line.startswith(name+' ')] for name in ['CONDUIT_PROTOCOL_PLAY','CONDUIT_PROTOCOL_PLAY_ALLOCATIONS','CONDUIT_PROTOCOL_PLAY_STOPPED','CONDUIT_PROTOCOL_REFUSAL','CONDUIT_PROTOCOL_OUTPUT']}
   receipt=dict(schema='conduit.usb/cdc-retirement-observation@1',validation='not-run',mode=a.mode,expected_commit=a.expected_commit,package_sha256=a.expected_package_sha256,build=build,media_receipt=r,qemu_arguments=argv,fixture_command=command,markers=markers,post_outcome_seconds=0 if terminal_at is None else time.monotonic()-terminal_at,pending_device_request_observed='FAULT_RETAINED_FIRST_IN '+a.mode in device_text,late_response_sent_after_stop='FAULT_LATE_RESPONSE_SENT_AFTER_STOP ' in device_text,late_native_completion_observed=False,source_hashes={str(path):sha(path) for path in [base/'run.py',base/'device.py',base.parent/'usb-serial-product-faults/device.py',base.parent/'usb-cdc-fixture/cdc_device.py']},transcript_hashes={path.name:sha(path) for path in out.iterdir() if path.is_file()})
   (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
   assert terminal_at is not None and markers['CONDUIT_PROTOCOL_PLAY_ALLOCATIONS'] and markers['CONDUIT_PROTOCOL_PLAY_STOPPED']
   assert receipt['pending_device_request_observed']
   assert 'REPEATED_DEVICE_EVENTS_DONE' in device_text
  finally:
   for process in [qemu,device]:
    if process is not None and process.poll() is None:
     process.terminate()
     try:process.wait(timeout=2)
     except subprocess.TimeoutExpired:process.kill();process.wait(timeout=2)
