use conduit_core::validate_canonical_structured_value;
fn main() {
 let args: Vec<_> = std::env::args().collect();
 assert_eq!(args.len(), 3);
 let log = std::fs::read_to_string(&args[1]).unwrap();
 let expected = std::fs::read(&args[2]).unwrap();
 assert_eq!(expected.len(), 1536);
 assert!(!log.contains("CONDUIT_PROTOCOL_REFUSAL "));
 assert!(!log.contains("panicked at"));
 let lines: Vec<_> = log.lines().collect();
 let outputs: Vec<_> = lines.iter().enumerate().filter(|(_, l)| l.starts_with("CONDUIT_PROTOCOL_OUTPUT port=ended ")).collect();
 assert_eq!(outputs.len(), 1);
 assert_eq!(lines.iter().filter(|line| line.starts_with("CONDUIT_PROTOCOL_OUTPUT ")).count(), 1);
 assert!(lines.iter().any(|line| line.starts_with("CONDUIT_PROTOCOL_PLAN ")));
 assert!(lines.iter().any(|line| line.starts_with("CONDUIT_PROTOCOL_PLAY ")));
 let position = outputs[0].0;
 let hex = lines[position + 1].trim();
 assert_eq!(hex.len() % 2, 0);
 assert!(log.ends_with("\n"));
 let bytes: Vec<_> = hex.as_bytes().as_chunks::<2>().0.iter().map(|pair| u8::from_str_radix(std::str::from_utf8(pair).unwrap(), 16).unwrap()).collect();
 let state = validate_canonical_structured_value(&bytes).unwrap();
 assert_eq!(state.record_field("phase").unwrap().unwrap().primitive_bytes("value/u64").unwrap(), 3u64.to_le_bytes());
 assert_eq!(state.record_field("terminal").unwrap().unwrap().primitive_bytes("value/bool").unwrap(), [1]);
 let pcm = state.record_field("pcm").unwrap().unwrap();
 let packets = pcm.record_field("packets").unwrap().unwrap();
 assert_eq!(packets.collection_length().unwrap(), 8);
 let mut retained = Vec::new();
 for i in 0..8 { retained.extend_from_slice(packets.collection_index(i).unwrap().unwrap().record_field("wire").unwrap().unwrap().primitive_bytes("value/bytes").unwrap()); }
 assert_eq!(retained, expected);
 let retired: Vec<_> = lines.iter().enumerate().filter(|(_,l)| l.starts_with("CONDUIT_PROTOCOL_RETIRED complete")).collect();
 assert_eq!(retired.len(), 1);
 assert!(retired[0].0 > position);
 println!("checked terminal phase=3 original PCM retained, retirement observed; wire verification required separately");
}
