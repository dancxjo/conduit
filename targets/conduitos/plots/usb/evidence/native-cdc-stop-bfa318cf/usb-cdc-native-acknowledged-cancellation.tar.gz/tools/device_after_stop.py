"""Owned DEVICE fixture only: defer one original late response until guest stop trace."""
import argparse, pathlib, sys, time
p=argparse.ArgumentParser(add_help=False)
p.add_argument('--guest-serial',type=pathlib.Path,required=True)
a,remaining=p.parse_known_args();sys.argv=[sys.argv[0]]+remaining
fixture=pathlib.Path(__file__).resolve().parent.parent/'usb-serial-product-faults/device.py'
text=fixture.read_text()
needle='        self.bulk_reply(packet_id,129,len(data),data=data)'
assert text.count(needle)==1
# Stop is not inferred from the device's cancel message. The late response waits
# for the separately emitted guest receipt after native/kernel/Body retirement.
replacement='''        limit=time.monotonic()+5
        while time.monotonic()<limit:
            raw=guest_serial.read_bytes() if guest_serial.exists() else b''
            if any(line.startswith(b'CONDUIT_PROTOCOL_PLAY_STOPPED ') for line in raw.splitlines()):
                print('FAULT_STOP_TRACE_OBSERVED_BEFORE_LATE_SEND',flush=True)
                self.bulk_reply(packet_id,129,len(data),data=data)
                print('FAULT_LATE_RESPONSE_SENT_AFTER_STOP '+str(packet_id),flush=True)
                break
            time.sleep(.01)
        else:
            raise RuntimeError('guest acknowledged stop receipt absent; no late response sent')'''
namespace={'__name__':'__main__','__file__':str(fixture),'time':time,'guest_serial':a.guest_serial.resolve()}
exec(compile(text.replace(needle,replacement),str(fixture),'exec'),namespace)
