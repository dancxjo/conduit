#!/usr/bin/env bash
set -euo pipefail
audio_task_root=/home/dancxjo/Documents/Codex/2026-10-10/goal-please-finish-and-close-conduit
audio_proof="$audio_task_root/work/audio-output-envelope-native"
audio_xtask="$audio_task_root/work/usb-target/debug/xtask"
cd "$audio_task_root/work/usb-audio-integration"
"$audio_xtask" make conduitos protocol-image \
  --kernel "$audio_proof/kernel/x86_64/conduitos" \
  --build-record "$audio_proof/kernel/x86_64/build.json" \
  --package "$audio_task_root/work/audio-observed-exact-package/protocol-source.json" \
  --root-request "$audio_proof/root-request-v5.json" \
  --output-dir "$audio_proof/media-v5"
AUDIO_DEVICE_OUTPUT="$audio_proof/device-v5" TMPDIR=/dev/shm PYTHONDONTWRITEBYTECODE=1 \
  "$audio_xtask" make conduitos protocol-run --media "$audio_proof/media-v5" \
  --output-dir "$audio_proof/run-v5" --seconds 90 --maximum-transcript-bytes 1048576 \
  --emulator "$audio_proof/qemu_audio_wrapper.py"
"$audio_task_root/work/audio-public-observed-decoder" \
  "$audio_proof/run-v5/serial.log" "$audio_proof/original-pcm.bin"
PYTHONDONTWRITEBYTECODE=1 python3 "$audio_proof/verify_wire.py" "$audio_proof/device-v5/wire.jsonl" "$audio_proof/original-pcm.bin"
PYTHONDONTWRITEBYTECODE=1 python3 "$audio_task_root/work/usb-audio-integration/targets/conduitos/plots/usb/proof/check_play_receipts.py" "$audio_proof/run-v5/serial.log"
