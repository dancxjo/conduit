from pathlib import Path
import os,subprocess,json,time,shutil,sys
w=Path(__file__).resolve().parent;repo=w/'conduit';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
out=w/('riscv64-graphical-product-'+source[:9]);out.mkdir(exist_ok=False);product='target/host-build/6057-riscv64-graphical-'+source[:9]
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0');env['PATH']=str(w/'tools/bin')+':'+env['PATH']
r={'source':source,'product':product,'commands':[],'status':'preparing'}
commands=[('preflight',['cargo','xtask','ci','pipeline','preflight','dd111fe3a81fb578d1e2271620eeb8b21ef60ddd']),('build',['cargo','xtask','make','host','build','targets/conduitos/profiles/conduitos-riscv64-graphical.host.conduit','--output',product]),('boot',['cargo','xtask','make','host','verify',product,'--boot'])]
for name,args in commands:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source and not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
 if shutil.disk_usage(repo).free < 4*1024**3:r['status']='storage-guard-before-'+name;(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');sys.exit(2)
 print('START',name,flush=True);start=time.monotonic();r['status']='running-'+name;(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 with (out/(name+'.log')).open('wb') as log:code=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 r['commands'].append({'name':name,'command':args,'exit_code':code,'seconds':round(time.monotonic()-start,3)});r['status']=('passed-'if code==0 else 'failed-')+name;(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('END',name,code,flush=True)
 if code:sys.exit(code)
 if name=='boot':shutil.copyfile(repo/'target/conduitos/riscv64/riscv64-product-proof.json',out/'product-proof.json')
r.update(status='commands-passed-review-pending',clean_after=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo)),source_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source);(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
