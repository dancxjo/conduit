from pathlib import Path
import os,subprocess,time,json,sys,shutil
w=Path(__file__).resolve().parent;repo=w/'conduit';tool=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
product=repo/'target/host-build/6057-riscv64-graphical-61084bb3a';manifest=json.loads((product/'build-manifest.json').read_text());out=w/('riscv64-graphical-verify-'+tool[:9]);out.mkdir(exist_ok=False);r={'collector_source':tool,'image_source':manifest['source_identity'],'image_sha256':manifest['image']['sha256'],'commands':[]}
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0');env['PATH']=str(w/'tools/bin')+':'+env['PATH']
for name,args in [('verify',['cargo','xtask','make','host','verify',str(product),'--boot']),('strict-clippy',['cargo','clippy','--locked','-p','xtask','-p','conduitos','--all-targets','--features','conduitos/native-compositor','--','-D','warnings'])]:
 start=time.monotonic();print('START',name,flush=True)
 with (out/(name+'.log')).open('wb') as log:code=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 r['commands'].append({'name':name,'command':args,'exit_code':code,'seconds':round(time.monotonic()-start,3)});r['status']=('passed-'if code==0 else 'failed-')+name;(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('END',name,code,flush=True)
 if code:sys.exit(code)
 if name=='verify':shutil.copyfile(repo/'target/conduitos/riscv64/riscv64-product-proof.json',out/'product-proof.json')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==tool;r.update(status='passed-review-pending',collector_source_clean_unchanged=True);(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
