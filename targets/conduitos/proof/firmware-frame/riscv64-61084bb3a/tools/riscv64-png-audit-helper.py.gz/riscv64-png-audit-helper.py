from pathlib import Path
import json,hashlib,gzip,struct,zlib,binascii,subprocess
sha=lambda b:hashlib.sha256(b).hexdigest()
def pixels(path):
 data=path.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n';p=8;parts=[];header=None
 while p<len(data):
  n=struct.unpack('>I',data[p:p+4])[0];kind=data[p+4:p+8];b=data[p+8:p+8+n];crc=struct.unpack('>I',data[p+8+n:p+12+n])[0];assert binascii.crc32(kind+b)&0xffffffff==crc;p+=12+n
  if kind==b'IHDR':header=struct.unpack('>IIBBBBB',b)
  if kind==b'IDAT':parts.append(b)
  if kind==b'IEND':break
 width,height,depth,color,compression,filtering,interlace=header;assert (depth,color,compression,filtering,interlace)==(8,6,0,0,0);raw=zlib.decompress(b''.join(parts));stride=width*4;assert len(raw)==height*(stride+1);prev=bytearray(stride);result=bytearray()
 for y in range(height):
  pos=y*(stride+1);f=raw[pos];row=bytearray(raw[pos+1:pos+1+stride]);assert 0<=f<=4
  for i in range(stride):
   a=row[i-4]if i>=4 else 0;b=prev[i];c=prev[i-4]if i>=4 else 0
   if f==1:v=a
   elif f==2:v=b
   elif f==3:v=(a+b)//2
   elif f==4:
    q=a+b-c;da,db,dc=abs(q-a),abs(q-b),abs(q-c);v=a if da<=db and da<=dc else b if db<=dc else c
   else:v=0
   row[i]=(row[i]+v)&255
  result.extend(row);prev=row
 return width,height,sha(result)

