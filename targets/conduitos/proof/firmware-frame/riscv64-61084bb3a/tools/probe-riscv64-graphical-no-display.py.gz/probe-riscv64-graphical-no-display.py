from pathlib import Path
import json,hashlib,subprocess,tempfile,socket,shutil,time,os
w=Path(__file__).resolve().parent;proof=json.loads((w/'riscv64-graphical-verify-22f9ee6fa/product-proof.json').read_text());directory=Path(proof['first']['graphical']['directory']);launch=json.loads((directory/'launch.json').read_text());out=w/'riscv64-graphical-no-display-61084bb3a';out.mkdir(exist_ok=False);sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert sha(launch['program'])==launch['emulator_sha256'] and sha(launch['image'])==launch['image_sha256'];sbi,code,template,_=launch['firmware_inputs']
for item in [sbi,code,template]:assert sha(item['path'])==item['sha256']
shutil.copyfile(template['path'],out/'vars.fd');assert sha(out/'vars.fd')==template['sha256'];r={'classification':'same normal graphical ISO with only ramfb provider removed','image_source':launch['image_source_identity'],'collector_source':launch['source_commit'],'image':launch['image'],'image_sha256':launch['image_sha256'],'emulator_sha256':launch['emulator_sha256'],'firmware_inputs':[sbi,code,template],'positive_capture':str(directory),'graphical_product_proved':False}
with tempfile.TemporaryDirectory(prefix='c6057-rv-neg-')as temp:
 endpoint=Path(temp)/'qmp';args=launch['arguments'];cmd=[launch['program']];i=0
 while i<len(args):
  arg=args[i]
  if arg=='-device' and args[i+1]=='ramfb':i+=2;continue
  if arg=='-qmp':cmd += [arg,f'unix:{endpoint},server=on,wait=off'];i+=2;continue
  if arg=='-serial':cmd += [arg,f'file:{out/"serial.log"}'];i+=2;continue
  if arg.startswith('node-name=pflash1,'):arg=f'node-name=pflash1,driver=file,filename={out/"vars.fd"}'
  cmd.append(arg);i+=1
 assert 'ramfb'not in cmd;r['arguments']=cmd;env=os.environ.copy();env.pop('QEMU_MODULE_DIR',None);env['QEMU_AUDIO_DRV']='none';start=time.monotonic();(out/'launch.json').write_text(json.dumps(r,indent=2)+'\n')
 with (out/'stderr.log').open('wb')as err:
  p=subprocess.Popen(cmd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=err)
  try:
   while p.poll()is None and time.monotonic()-start<45:
    serial=(out/'serial.log').read_bytes()if(out/'serial.log').exists()else b'';assert len(serial)<=1024*1024
    if any(b'CONDUIT_RISCV64_PRODUCT_REFUSAL 'in line for line in serial.splitlines(keepends=True)if line.endswith(b'\n'))or b'CONDUIT_FIRMWARE_FACE 'in serial:break
    time.sleep(.1)
   if p.poll()is None and endpoint.exists():
    with socket.socket(socket.AF_UNIX)as sock:
     sock.settimeout(5);sock.connect(str(endpoint));f=sock.makefile('rwb');trace=[]
     def receive():
      line=f.readline(16384);assert line and len(line)<16384;v=json.loads(line);trace.append(v);return v
     receive()
     def request(name,args=None):
      f.write(json.dumps({'execute':name,**({'arguments':args}if args else{})}).encode()+b'\n');f.flush()
      while True:
       v=receive()
       if 'return'in v or 'error'in v:return v
     request('qmp_capabilities');r['screendump_result']=request('screendump',{'filename':str(out/'display.ppm')});(out/'qmp.json').write_text(json.dumps(trace,indent=2)+'\n')
  finally:
   if p.poll()is None:p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 r.update(elapsed_ms=int((time.monotonic()-start)*1000),exit_code=p.returncode)
assert sha(template['path'])==template['sha256'] and sha(launch['image'])==launch['image_sha256'];serial=(out/'serial.log').read_bytes();r.update(template_unchanged=True,same_image_unchanged=True,guest_refusal_observed=b'CONDUIT_RISCV64_PRODUCT_REFUSAL display-absent'in serial,graphical_show_observed=b'CONDUIT_FIRMWARE_FACE 'in serial);r['files']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in out.iterdir()if p.is_file()and p.name!='vars.fd'];(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['guest_refusal_observed','graphical_show_observed','elapsed_ms']},indent=2));assert r['guest_refusal_observed'] and not r['graphical_show_observed']
