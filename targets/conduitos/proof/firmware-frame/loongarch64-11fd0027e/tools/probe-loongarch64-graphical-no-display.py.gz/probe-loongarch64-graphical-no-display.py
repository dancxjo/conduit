from pathlib import Path
import json,hashlib,subprocess,tempfile,socket,shutil,time,os
w=Path(__file__).resolve().parent;proof=json.loads((w/'loongarch64-graphical-product-11fd0027e/product-proof.json').read_text());directory=Path(proof['first']['graphical']['directory']);launch=json.loads((directory/'launch.json').read_text());out=w/'loongarch64-graphical-no-display-11fd0027e';out.mkdir(exist_ok=False);sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
repo=w/'conduit-loongarch-prep';image=Path(launch['image']);image=image if image.is_absolute()else repo/image
assert sha(launch['program'])==launch['emulator_sha256'] and sha(image)==launch['image_sha256'];firmware=launch['firmware_inputs'][0];assert len(launch['firmware_inputs'])==1 and sha(firmware['path'])==firmware['sha256']
r={'classification':'same normal graphical ISO with only ramfb provider removed','image_source':launch['image_source_identity'],'collector_source':launch['source_commit'],'image':launch['image'],'image_sha256':launch['image_sha256'],'emulator_sha256':launch['emulator_sha256'],'firmware_inputs':[firmware],'positive_capture':str(directory),'graphical_product_proved':False}
with tempfile.TemporaryDirectory(prefix='c6057-la-neg-')as temp:
 endpoint=Path(temp)/'qmp';entropy=Path(temp)/'entropy.bin';secret=bytearray(os.getrandom(4096,os.GRND_NONBLOCK));assert len(secret)==4096
 fd=os.open(entropy,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:assert os.write(fd,secret)==4096
 finally:
  os.close(fd)
  for j in range(len(secret)):secret[j]=0
 args=launch['arguments'];cmd=[launch['program']];i=0
 while i<len(args):
  arg=args[i]
  if arg=='-device' and args[i+1]=='ramfb':i+=2;continue
  if arg=='-qmp':cmd += [arg,f'unix:{endpoint},server=on,wait=off'];i+=2;continue
  if arg=='-serial':cmd += [arg,f'file:{out/"serial.log"}'];i+=2;continue
  if arg=='-fw_cfg':cmd += [arg,f'name=opt/conduitos/cryptographic-entropy@1,file={entropy}'];i+=2;continue
  cmd.append(arg);i+=1
 assert 'ramfb'not in cmd;r['arguments']=cmd;env=os.environ.copy();env.pop('QEMU_MODULE_DIR',None);env['QEMU_AUDIO_DRV']='none';start=time.monotonic();(out/'launch.json').write_text(json.dumps(r,indent=2)+'\n')
 with (out/'stderr.log').open('wb')as err:
  p=subprocess.Popen(cmd,cwd=repo,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=err)
  try:
   while p.poll()is None and time.monotonic()-start<45:
    serial=(out/'serial.log').read_bytes()if(out/'serial.log').exists()else b'';assert len(serial)<=1024*1024
    if any(b'CONDUIT_LOONGARCH64_PRODUCT_REFUSAL 'in line for line in serial.splitlines(keepends=True)if line.endswith(b'\n'))or b'CONDUIT_FIRMWARE_FACE 'in serial:break
    time.sleep(.1)
   if p.poll()is None and endpoint.exists():
    with socket.socket(socket.AF_UNIX)as sock:
     sock.settimeout(5);sock.connect(str(endpoint));f=sock.makefile('rwb');trace=[]
     def receive():
      line=f.readline(16384);assert line and len(line)<16384;v=json.loads(line);trace.append(v);return v
     receive()
     def request(name,args=None):
      f.write(json.dumps({'execute':name,**({'arguments':args}if args else{})}).encode()+b'\n');f.flush()
      while True:
       v=receive()
       if 'return'in v or 'error'in v:return v
     request('qmp_capabilities');r['screendump_result']=request('screendump',{'filename':str(out/'display.ppm')});(out/'qmp.json').write_text(json.dumps(trace,indent=2)+'\n')
  finally:
   if p.poll()is None:p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 r.update(elapsed_ms=int((time.monotonic()-start)*1000),exit_code=p.returncode)
assert sha(firmware['path'])==firmware['sha256'] and sha(image)==launch['image_sha256'];assert not entropy.exists();serial=(out/'serial.log').read_bytes();r.update(firmware_rom_unchanged=True,entropy_bytes_retained=False,entropy_hash_retained=False,ephemeral_entropy_removed=True,same_image_unchanged=True,guest_refusal_observed=b'CONDUIT_LOONGARCH64_PRODUCT_REFUSAL display-absent'in serial,graphical_show_observed=b'CONDUIT_FIRMWARE_FACE 'in serial);r['files']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in out.iterdir()if p.is_file()and p.name!='vars.fd'];(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['guest_refusal_observed','graphical_show_observed','elapsed_ms']},indent=2));assert r['guest_refusal_observed'] and not r['graphical_show_observed']
