from pathlib import Path
import os,subprocess,json,time,shutil,sys,signal,hashlib
w=Path(__file__).resolve().parent;repo=w/'conduit-loongarch-prep';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert source.startswith('11fd0027e')and not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
out=w/('loongarch64-graphical-product-'+source[:9]);out.mkdir(exist_ok=False);product='target/host-build/6057-loongarch64-graphical-'+source[:9];target=repo/'target/conduitos/loongarch64';before=set(target.glob('loongarch64-frame-*'))
for name in ['conduitos','conduitos.iso','image.json','build.json','loongarch64-product-proof.json','loongarch64-product-observatory.json']:
 p=target/name
 if p.is_file():shutil.copyfile(p,out/('prior-'+name))
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0');env['PATH']=str(w/'tools/bin')+':'+env['PATH'];base=subprocess.check_output(['git','rev-parse','5b2661619'],cwd=repo,text=True).strip()
r={'source':source,'base':base,'product':product,'commands':[],'status':'preparing'};receipt=out/'receipt.json'
commands=[('preflight',['cargo','xtask','ci','pipeline','preflight',base]),('prepare-tools-and-firmware',['cargo','xtask','make','conduitos','prepare-loongarch64-domain-emulator','--graphical']),('build',['cargo','xtask','make','host','build','targets/conduitos/profiles/conduitos-loongarch64-graphical.host.conduit','--output',product]),('boot',['cargo','xtask','make','host','verify',product,'--boot'])]
for name,args in commands:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source and not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
 if shutil.disk_usage(repo).free<4*1024**3:r['status']='storage-guard-before-'+name;receipt.write_text(json.dumps(r,indent=2)+'\n');sys.exit(2)
 print('START',name,flush=True);start=time.monotonic();r['status']='running-'+name;entry={'name':name,'command':args};r['commands'].append(entry);receipt.write_text(json.dumps(r,indent=2)+'\n')
 with(out/(name+'.log')).open('wb')as log:
  p=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);entry['pid']=p.pid;receipt.write_text(json.dumps(r,indent=2)+'\n')
  while p.poll()is None:
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:
    if shutil.disk_usage(repo).free<4*1024**3:
     entry['resource_stop']='root disk below4GiB';os.killpg(p.pid,signal.SIGTERM)
     try:p.wait(timeout=10)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 entry.update(exit_code=p.returncode,seconds=round(time.monotonic()-start,3),log_sha256=hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest());r['status']=('passed-'if p.returncode==0 else'failed-')+name;receipt.write_text(json.dumps(r,indent=2)+'\n');print('END',name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
 if name=='boot':shutil.copyfile(target/'loongarch64-product-proof.json',out/'product-proof.json')
new=sorted(set(target.glob('loongarch64-frame-*'))-before);assert len(new)==2,new
r.update(status='commands-passed-review-pending',capture_directories=[str(p)for p in new],clean_after=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo)),source_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source);receipt.write_text(json.dumps(r,indent=2)+'\n')
