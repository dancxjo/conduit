from pathlib import Path
import os,subprocess,time,json,shutil,hashlib,sys
w=Path(__file__).resolve().parent;repo=w/'conduit-ia32-prep';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
out=w/('ia32-graphical-product-'+source[:9]);out.mkdir(exist_ok=False);env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(w/'conduit/target'),CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0');env['PATH']=str(w/'tools/bin')+':'+env['PATH']
receipt={'source':source,'status':'preparing','commands':[]};products={}
commands=[('preflight',['cargo','xtask','ci','pipeline','preflight','dd92bde82017fe685404ef9197b56d3b3127006c'])]
for label,profile in [('serial','conduitos-ia32-pc'),('graphical','conduitos-ia32-graphical')]:
 product='target/host-build/6057-ia32-'+label+'-'+source[:9];products[label]=product
 commands += [(label+'-build',['cargo','xtask','make','host','build','targets/conduitos/profiles/'+profile+'.host.conduit','--output',product]),(label+'-boot',['cargo','xtask','make','host','verify',product,'--boot'])]
receipt['products']=products
for name,command in commands:
 assert source==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() and not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
 if shutil.disk_usage(repo).free<4*1024**3:receipt['status']='storage-guard-before-'+name;(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');sys.exit(2)
 entry={'name':name,'command':command,'started':time.time()};receipt['commands'].append(entry);receipt['status']='running-'+name;(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('START',name,flush=True)
 with (out/(name+'.log')).open('wb')as log:result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 entry.update(exit_code=result.returncode,finished=time.time());(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('END',name,result.returncode,flush=True)
 if result.returncode:receipt['status']='failed-'+name;(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');sys.exit(result.returncode)
 if name.endswith('-boot'):
  label=name[:-5];proof=repo/'target/conduitos/ia32/ia32-product-proof.json';shutil.copyfile(proof,out/(label+'-product-proof.json'))
  for src in (repo/'target/conduitos/ia32').glob('ia32-product-*.log'):shutil.copyfile(src,out/(label+'-'+src.name))
receipt.update(status='commands-passed-review-pending',clean_after=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()),source_unchanged=source==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip());(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
