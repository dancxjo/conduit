from pathlib import Path
import json,sys,hashlib,subprocess,tempfile,socket,shutil,time,os
proof=Path(sys.argv[1]);value=json.loads(proof.read_text());positive=value['first']['graphical'];directory=Path(positive['directory']);launch=json.loads((directory/'launch.json').read_text());out=Path(__file__).resolve().parent/('ia32-graphical-no-display-'+launch['image_source_identity'][:9]);out.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert sha(launch['program'])==launch['emulator_sha256'] and sha(launch['image'])==launch['image_sha256'];code,template,_=launch['firmware_inputs'];assert sha(code['path'])==code['sha256'] and sha(template['path'])==template['sha256'];shutil.copyfile(template['path'],out/'vars.fd')
r={'classification':'actual same-image negative launch with VGA provider removed','source_identity':launch['image_source_identity'],'positive_capture':str(directory),'image':launch['image'],'image_sha256':launch['image_sha256'],'emulator_sha256':launch['emulator_sha256'],'firmware_inputs':[code,template],'graphical_product_proved':False,'physical_scanout_proved':False,'gpu_acceleration_proved':False}
with tempfile.TemporaryDirectory(prefix='c6057-ia-neg-')as temp:
 endpoint=Path(temp)/'qmp';args=launch['arguments'];cmd=[launch['program']];i=0
 while i<len(args):
  arg=args[i]
  if arg=='-qmp':cmd += [arg,f'unix:{endpoint},server=on,wait=off'];i+=2;continue
  if arg=='-debugcon':cmd += [arg,f'file:{out/"serial.log"}'];i+=2;continue
  if arg.startswith('if=pflash,format=raw,file='):arg=f'if=pflash,format=raw,file={out/"vars.fd"}'
  cmd.append(arg);i+=1
 cmd += ['-vga','none'];r['arguments']=cmd;start=time.monotonic()
 with (out/'stderr.log').open('wb')as err:
  p=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=err)
  try:
   while p.poll()is None and time.monotonic()-start<45:
    serial=(out/'serial.log').read_bytes()if(out/'serial.log').exists()else b''
    assert len(serial)<=1024*1024
    if b'CONDUIT_IA32_PRODUCT_REFUSAL 'in serial or b'CONDUIT_FIRMWARE_FACE 'in serial:break
    time.sleep(.1)
   if p.poll()is None and endpoint.exists():
    with socket.socket(socket.AF_UNIX)as sock:
     sock.settimeout(5);sock.connect(str(endpoint));f=sock.makefile('rwb');trace=[]
     def receive():
      line=f.readline(16384);assert line and len(line)<16384;v=json.loads(line);trace.append(v);return v
     receive()
     def request(name,args=None):
      f.write(json.dumps({'execute':name,**({'arguments':args}if args else{})}).encode()+b'\n');f.flush()
      while True:
       v=receive()
       if 'return'in v or 'error'in v:return v
     request('qmp_capabilities');request('stop');r['screendump_result']=request('screendump',{'filename':str(out/'display.ppm')});(out/'qmp.json').write_text(json.dumps(trace,indent=2)+'\n')
  finally:
   if p.poll()is None:p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 r.update(elapsed_ms=int((time.monotonic()-start)*1000),exit_code=p.returncode)
assert sha(template['path'])==template['sha256'] and sha(launch['image'])==launch['image_sha256'];serial=(out/'serial.log').read_bytes();r['template_unchanged']=True;r['same_image_unchanged']=True;r['guest_refusal_observed']=b'CONDUIT_IA32_PRODUCT_REFUSAL display-absent'in serial;r['graphical_show_observed']=b'CONDUIT_FIRMWARE_FACE 'in serial;r['files']=[{'path':x.name,'sha256':sha(x),'bytes':x.stat().st_size}for x in out.iterdir()if x.is_file()and x.name!='vars.fd'];(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['guest_refusal_observed','graphical_show_observed','elapsed_ms']},indent=2));assert not r['graphical_show_observed']
