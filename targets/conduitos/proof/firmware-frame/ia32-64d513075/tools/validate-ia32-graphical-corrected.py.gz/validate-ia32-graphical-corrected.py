from pathlib import Path
import subprocess,os,json,hashlib,time,sys
root=Path(__file__).resolve().parent;repo=root/'conduit-ia32-prep';out=root/'ia32-graphical-validation-corrected';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'conduit/target'),CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
files=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines();sources={p:hashlib.sha256((repo/p).read_bytes()).hexdigest()for p in files}
commands=[('conduitos-tooling',['cargo','test','--locked','-p','xtask','commands::conduitos::','--','--nocapture']),('multiboot',['cargo','test','--locked','-p','conduitos','--lib','--features','native-compositor','boot::multiboot']),('scanout-policy',['cargo','test','--locked','-p','conduitos','--lib','--features','native-compositor','ia32_scanout_policy']),('make',['cargo','test','--locked','-p','conduitos','--lib','--features','native-compositor','make::tests'])]
receipt={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_files':sources,'commands':[]}
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb')as log:result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt['commands'].append({'name':name,'command':command,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3)});(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==v for p,v in sources.items());receipt['source_files_unchanged']=True;receipt['status']='passed';(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
