from pathlib import Path
import json,hashlib,gzip,struct,zlib,binascii,subprocess
w=Path(__file__).resolve().parent;repo=w/'conduit-ia32-prep';run=w/'ia32-graphical-product-64d513075-portable-bases';receipt=json.loads((run/'receipt.json').read_text());assert receipt['status']=='commands-passed-review-pending' and receipt['clean_after'] and receipt['source_unchanged'];proof=json.loads((run/'graphical-product-proof.json').read_text());product=repo/receipt['products']['graphical'];m=json.loads((product/'build-manifest.json').read_text());source=m['source_identity'];assert source==receipt['source']==proof['base_commit'];sha=lambda b:hashlib.sha256(b).hexdigest();kernel=(product/m['kernel']['file']).read_bytes();image=(product/m['image']['file']).read_bytes();assert sha(kernel)==m['kernel']['sha256'];assert sha(image)==m['image']['sha256']==proof['image_sha256'];offset=image.find(kernel);assert offset>=0

def pixels(path):
 data=path.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n';p=8;parts=[];header=None
 while p<len(data):
  n=struct.unpack('>I',data[p:p+4])[0];kind=data[p+4:p+8];b=data[p+8:p+8+n];crc=struct.unpack('>I',data[p+8+n:p+12+n])[0];assert binascii.crc32(kind+b)&0xffffffff==crc;p+=12+n
  if kind==b'IHDR':header=struct.unpack('>IIBBBBB',b)
  if kind==b'IDAT':parts.append(b)
  if kind==b'IEND':break
 width,height,depth,color,compression,filtering,interlace=header;assert (depth,color,compression,filtering,interlace)==(8,6,0,0,0);raw=zlib.decompress(b''.join(parts));stride=width*4;assert len(raw)==height*(stride+1);prev=bytearray(stride);result=bytearray()
 for y in range(height):
  pos=y*(stride+1);f=raw[pos];row=bytearray(raw[pos+1:pos+1+stride]);assert 0<=f<=4
  for i in range(stride):
   a=row[i-4]if i>=4 else 0;b=prev[i];c=prev[i-4]if i>=4 else 0
   if f==1:v=a
   elif f==2:v=b
   elif f==3:v=(a+b)//2
   elif f==4:
    q=a+b-c;da,db,dc=abs(q-a),abs(q-b),abs(q-c);v=a if da<=db and da<=dc else b if db<=dc else c
   else:v=0
   row[i]=(row[i]+v)&255
  result.extend(row);prev=row
 return width,height,sha(result)

boots=[]
for key in ['first','second']:
 b=proof[key];g=b['graphical'];f=g['face'];mapping=g['mapping'];directory=Path(g['directory']);launch=json.loads((directory/'launch.json').read_text());png=directory/g['frame']['png'];assert launch['image_source_identity']==source==launch['source_commit'] and launch['source_dirty']==False;assert launch['image_sha256']==proof['image_sha256'];assert sha(png.read_bytes())==g['frame']['png_sha256'];width,height,px=pixels(png);assert [width,height]==[1280,800] and px==g['frame']['pixel_sha256'];assert f['local_input_available']==False and f['status']=='shown';assert f['show']['manifestation']['lifecycle']=='Available';assert f['show']['face_id']==f['face']['identity']==f['mask_render']['face_id'];assert f['show']['mask_plan_id']==f['mask_render']['mask_plan_id'];assert f['show']['mask_active_play_id']==f['mask_render']['active_play_id'];assert f['framebuffer']['base_id']==mapping['base_id']==b['framebuffer_observation']['framebuffer']['base_id'];assert f['framebuffer']['pitch']==5120 and f['framebuffer']['bits_per_pixel']==32;assert mapping['physical_start']==2147483648 and mapping['byte_length']==4096000 and mapping['exclusive_writer']==True;assert all(f[k]==b[k] for k in ['profile_id','build_id','image_id']);assert b['image_id']==m['resolved_build']['image_id'];assert mapping['host_id']==b['host_id'] and mapping['boot_id']==b['boot_id'];assert len(launch['firmware_inputs'])==3 and launch['firmware_inputs'][1]['sha256']==launch['firmware_inputs'][2]['sha256'];boots.append({'checkpoint':key,'directory':str(directory),'host_id':b['host_id'],'boot_id':b['boot_id'],'face_id':f['face']['identity'],'show_id':f['show']['show_id'],'png_sha256':g['frame']['png_sha256'],'pixel_sha256':px,'width':width,'height':height,'pitch':5120,'bits_per_pixel':32,'boot_to_capture_millis':g['boot_to_capture_millis'],'kernel_signs':f['mask_render']['kernel_signs']})
assert boots[0]['host_id']!=boots[1]['host_id'] and boots[0]['boot_id']!=boots[1]['boot_id'];f=proof['first']['graphical']['face'];a_path=repo/'targets/conduitos/proof/firmware-frame/aarch64-f96860659/first/capture.json.gz';a=json.loads(gzip.decompress(a_path.read_bytes()))['face'];old_path=w/'gallery-two-architecture-semantic-audit.json';old=json.loads(old_path.read_text());keys=['source_document_id','checked_plot_id','expanded_plot_id'];basis={k:f['face']['basis'][k]for k in keys};assert basis=={k:a['face']['basis'][k]for k in keys}==old['same_face_source_checked_expanded'];assert f['show']['mask_plot']==a['show']['mask_plot']==old['same_mask_plot'];actions=lambda face:{x['identity']:x['availability']for x in face['face']['actions']};assert actions(f)==actions(a);plots=lambda face:sorted(x['identity']for x in face['face']['subjects']if x.get('role')=='Plot');assert len(plots(f))==5 and plots(f)==plots(a)
result={'classification':'independent current IA32 normal-product artifact/pixel/semantic audit','source':source,'image_sha256':sha(image),'kernel_sha256':sha(kernel),'complete_kernel_found_in_iso_at_byte':offset,'boots':boots,'same_face_source_checked_expanded':basis,'same_mask_plot':f['show']['mask_plot'],'same_five_plot_subjects_as_aarch64':plots(f),'same_owner_action_availability_as_aarch64':actions(f),'x86_owner_action_availability_differs_as_previously_recorded':old['x86']['owner_action_availability'],'aarch64_capture_sha256':sha(a_path.read_bytes()),'two_architecture_audit_sha256':sha(old_path.read_bytes()),'limits':'IA32 normal UEFI32 framebuffer only; no local input, physical scanout, GPU acceleration, accepted Candidate/Integration/release or all-five completion proved'};(run/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('Two current IA32 boots: whole ELF/ISO custody, PNG CRC/pixel digests, acknowledged Shows and three-architecture authored semantic identities verified')
