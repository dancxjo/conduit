from pathlib import Path
import json,hashlib,subprocess,tempfile,socket,time,os,shutil
root=Path(__file__).resolve().parent; previous=json.loads((root/'thingos-riscv-g0-matched-modules/receipt.json').read_text()); out=root/'riscv-no-ramfb-g0';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
for item in previous['inputs']: assert sha(item['path'])==item['sha256'],item['path']
env=os.environ.copy();env.update(previous['environment']);qemu=previous['arguments'][0]
r={'classification':'historical-normal-product-negative-display-and-serial-baseline','source_identity':previous['historical_image_manifest']['source_identity'],'manifest':previous['historical_image_manifest'],'inputs':previous['inputs'],'graphical_product_proved':False,'physical_scanout_proved':False,'gpu_acceleration_proved':False}
for label,args in [('device-help',['-machine','virt','-device','help']),('machine-help',['-machine','help'])]:
 p=subprocess.run([qemu,*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10);assert p.returncode==0;(out/(label+'.log')).write_bytes(p.stdout)
assert b'ramfb' in (out/'device-help.log').read_bytes()
fw=root/'thingos-firmware/riscv64';shutil.copyfile(fw/'vars.fd',out/'vars.fd');template=sha(fw/'vars.fd')
with tempfile.TemporaryDirectory(prefix='c6057-neg-') as tmp:
 endpoint=Path(tmp)/'qmp';cmd=[];old=previous['arguments'];i=0
 while i<len(old):
  arg=old[i]
  if arg=='-device' and old[i+1]=='ramfb':i+=2;continue
  if arg=='-qmp':cmd += [arg,f'unix:{endpoint},server=on,wait=off'];i+=2;continue
  if arg=='-serial':cmd += [arg,f'file:{out/"serial.log"}'];i+=2;continue
  if arg.startswith('node-name=pflash1,'):arg=f'node-name=pflash1,driver=file,filename={out/"vars.fd"}'
  cmd.append(arg);i+=1
 r['arguments']=cmd;r['environment']=previous['environment'];r['emulator_version']=subprocess.check_output([qemu,'--version'],env=env,text=True);start=time.monotonic()
 with (out/'stderr.log').open('wb') as err:
  p=subprocess.Popen(cmd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=err)
  try:
   while p.poll() is None and time.monotonic()-start<45:
    text=(out/'serial.log').read_text(errors='replace') if (out/'serial.log').exists() else ''
    if 'CONDUIT_RISCV64_PRODUCT_REFUSAL ' in text or 'CONDUIT_BOOT_STAGE riscv64-product-ready' in text:break
    time.sleep(.2)
   if p.poll() is None and endpoint.exists():
    with socket.socket(socket.AF_UNIX) as sock:
     sock.settimeout(5);sock.connect(str(endpoint));stream=sock.makefile('rwb');trace=[]
     def receive():
      line=stream.readline(16384);assert line and len(line)<16384;v=json.loads(line);trace.append(v);return v
     receive()
     def request(name,args=None):
      stream.write(json.dumps({'execute':name,**({'arguments':args} if args else {})}).encode()+b'\n');stream.flush()
      while True:
       v=receive()
       if 'return' in v or 'error' in v:return v
     request('qmp_capabilities');request('stop');r['screendump_result']=request('screendump',{'filename':str(out/'display.ppm')});(out/'qmp.json').write_text(json.dumps(trace,indent=2)+'\n')
  finally:
   if p.poll() is None:p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 r['exit_code']=p.returncode;r['elapsed_ms']=int((time.monotonic()-start)*1000)
assert sha(fw/'vars.fd')==template;r['template_vars_unchanged']=True
text=(out/'serial.log').read_text(errors='replace');r['serial_product_ready_observed']='CONDUIT_BOOT_STAGE riscv64-product-ready' in text;r['negative_no_display_observed']='error' in r.get('screendump_result',{})
r['files']=[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in out.iterdir() if f.is_file() and f.name!='vars.fd'];(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit_code','elapsed_ms','serial_product_ready_observed','negative_no_display_observed','screendump_result']},indent=2));print(text[-1300:])
