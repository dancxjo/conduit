from pathlib import Path
import json,subprocess,os,tempfile,socket,time,shutil,hashlib
root=Path(__file__).resolve().parent;prior=json.loads((root/'riscv-no-ramfb-g0/receipt.json').read_text());out=root/'riscv-default-display-audit';out.mkdir(exist_ok=False);env=os.environ.copy();env.update(prior['environment']);shutil.copyfile(root/'thingos-firmware/riscv64/vars.fd',out/'vars.fd')
with tempfile.TemporaryDirectory(prefix='c6057-tree-') as tmp:
 endpoint=Path(tmp)/'qmp';cmd=[];old=prior['arguments'];i=0
 while i<len(old):
  arg=old[i]
  if arg=='-qmp':cmd += [arg,f'unix:{endpoint},server=on,wait=off'];i+=2;continue
  if arg=='-serial':cmd += [arg,'none'];i+=2;continue
  if arg.startswith('node-name=pflash1,'):arg=f'node-name=pflash1,driver=file,filename={out/"vars.fd"}'
  cmd.append(arg);i+=1
 cmd.append('-S');trace=[]
 with (out/'stderr.log').open('wb') as err:
  p=subprocess.Popen(cmd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=err)
  try:
   start=time.monotonic()
   while not endpoint.exists() and p.poll() is None and time.monotonic()-start<5:time.sleep(.05)
   with socket.socket(socket.AF_UNIX) as sock:
    sock.settimeout(5);sock.connect(str(endpoint));f=sock.makefile('rwb')
    def receive():
     line=f.readline(131072);assert line and len(line)<131072;v=json.loads(line);trace.append(v);return v
    receive()
    def request(name,args=None):
     f.write(json.dumps({'execute':name,**({'arguments':args} if args else {})}).encode()+b'\n');f.flush()
     while True:
      v=receive()
      if 'return' in v or 'error' in v:return v
    assert 'return' in request('qmp_capabilities')
    for name,args in [('query-pci',None),('human-monitor-command',{'command-line':'info qtree'}),('human-monitor-command',{'command-line':'info roms'})]:
     result=request(name,args);(out/(name+('-roms' if args and 'roms' in args['command-line'] else '')+'.json')).write_text(json.dumps(result,indent=2)+'\n')
  finally:
   if p.poll() is None:p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
(out/'qmp.json').write_text(json.dumps(trace,indent=2)+'\n');(out/'receipt.json').write_text(json.dumps({'classification':'paused initial device inventory only','guest_instructions_executed':False,'arguments':cmd,'inputs':prior['inputs'],'files':[{'path':x.name,'sha256':hashlib.file_digest(x.open('rb'),'sha256').hexdigest()} for x in out.iterdir() if x.is_file() and x.name!='vars.fd']},indent=2)+'\n');print((out/'human-monitor-command.json').read_text())
