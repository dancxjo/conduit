from pathlib import Path
import os,subprocess,json,time,sys,hashlib
w=Path(__file__).resolve().parent;repo=w/'conduit';out=w/'riscv64-graphics-tool-validation';out.mkdir(exist_ok=False);env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0');commands=[('shared-probe-tests',['cargo','test','--locked','-p','xtask','qemu_source::graphics','--','--nocapture']),('cli-tests',['cargo','test','--locked','-p','xtask','graphical_riscv_emulator_is_an_explicit_preparation_option','--','--nocapture']),('strict-clippy',['cargo','clippy','--locked','-p','xtask','--all-targets','--','-D','warnings'])];files=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines();sources={p:hashlib.sha256((repo/p).read_bytes()).hexdigest()for p in files};receipt={'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':sources,'commands':[]}
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb')as log:r=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt['commands'].append({'name':name,'command':args,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3)});(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==v for p,v in sources.items());receipt['files_unchanged']=True;receipt['status']='passed';(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
