from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent;positive=w/'prepared-riscv64-ramfb-g0';negative=w/'prepared-riscv64-no-ramfb-g0-corrected';a=json.loads((positive/'receipt.json').read_text());b=json.loads((negative/'receipt.json').read_text())
for receipt,directory in [(a,positive),(b,negative)]:
 for row in receipt['inputs']:
  p=Path(row['path']);assert p.stat().st_size==row['bytes'];assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256']
 for row in receipt['files']:
  p=directory/row['path'];assert p.stat().st_size==row['bytes'];assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256']
 assert receipt['template_vars_unchanged']
assert 'ramfb' in a['arguments'] and 'ramfb' not in b['arguments']
assert 'CONDUIT_RISCV64_PRODUCT_REFUSAL observatory-framebuffer-unrepresented' in (positive/'serial.log').read_text(errors='replace')
records=[]
for line in (negative/'serial.log').read_text(errors='replace').splitlines():
 if 'CONDUIT_RISCV64_PRODUCT ' in line:records.append(json.loads(line.split('CONDUIT_RISCV64_PRODUCT ',1)[1]))
assert len(records)==1;r=records[0];m=b['manifest'];assert r['status']=='ready'
for runtime,manifest in [('profile_id','profile_id'),('build_id','build_id'),('image_id','resolved_description_binding')]:assert r[runtime]==m[manifest]
assert r['presenter_implementation_id']=='presenter/riscv64-linear-sbi-console@1';assert r['semantic_result']=='HELLO, CONDUITOS' and r['timer_irq_wakes']>=1
assert hashlib.sha256((negative/'display.ppm').read_bytes()).hexdigest()=='0febc060e4d667cae5354a4b65e1cbad7ffb0df86eb00fd445e7cd4e2f77e9b6'
assert m['source_identity']=='79a04199eeaea4721bb2405c7bbb699a72cea25c'
audit={'classification':'independent prepared-tools historical normal-product G0 audit','runtime_source':m['source_identity'],'all_actual_input_and_output_hashes_verified':True,'profile_build_logical_image_joined':True,'serial_ready':r,'ramfb_refusal_verified':True,'no_ramfb_is_exact_paused_control_placeholder':True,'graphical_face_or_show_proved':False,'first_misselected_variant_not_counted':True}
(w/'prepared-riscv64-g0-independent-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print('Actual input/output hashes and serial Profile/Build/logical Image/Source joins verified')
