from pathlib import Path
import json,hashlib,subprocess,tempfile,socket,time,os,shutil,sys
root=Path(__file__).resolve().parent; previous=json.loads((root/'thingos-riscv-g0-matched-modules/receipt.json').read_text()); label=sys.argv[1];assert label in ['ramfb','no-ramfb'];out=root/('prepared-riscv64-'+label+'-g0-corrected');out.mkdir(exist_ok=False)
cache=Path(json.loads((root/'riscv64-graphical-recipe-staged.json').read_text())['directory']);firmware=root/'conduit/target/conduitos/toolchain/edk2-riscv64'
replacements={previous['arguments'][0]:str(cache/'qemu-system-riscv64'),previous['arguments'][previous['arguments'].index('-bios')+1]:str(cache/'fw_dynamic.bin'),str(root/'thingos-firmware/riscv64/code.fd'):str(firmware/'code.fd'),str(root/'thingos-firmware/riscv64/vars.fd'):str(firmware/'vars.fd')}
for item in previous['inputs']:
 item['path']=replacements.get(item['path'],item['path'])
 if item['path']==str(cache/'qemu-system-riscv64'):item['sha256']='7cf442811288219dfa1e99f7b1a3766e652aed550377777b3b2ad89cf54038ba'
 item['bytes']=Path(item['path']).stat().st_size
previous['arguments']=[replacements.get(a,a).replace(str(root/'thingos-firmware/riscv64/code.fd'),str(firmware/'code.fd'))for a in previous['arguments']]
previous['environment']={'QEMU_AUDIO_DRV':'none'}
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
for item in previous['inputs']: assert sha(item['path'])==item['sha256'],item['path']
env=os.environ.copy();env.pop('QEMU_MODULE_DIR',None);env.update(previous['environment']);qemu=previous['arguments'][0]
r={'classification':'prepared-tools-historical-normal-product-machine-probe-'+label,'firmware_preparation_source':'231bb012dd7653e926d3fa69e421b9541e1621c5','emulator_preparation_source':'6162901d6e02b7e6d7d6b3566627ec4dec0c395a','source_identity':previous['historical_image_manifest']['source_identity'],'manifest':previous['historical_image_manifest'],'inputs':previous['inputs'],'graphical_product_proved':False,'physical_scanout_proved':False,'gpu_acceleration_proved':False}
for help_label,args in [('device-help',['-machine','virt','-device','help']),('machine-help',['-machine','help'])]:
 p=subprocess.run([qemu,*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10);assert p.returncode==0;(out/(help_label+'.log')).write_bytes(p.stdout)
assert b'ramfb' in (out/'device-help.log').read_bytes()
fw=firmware;shutil.copyfile(fw/'vars.fd',out/'vars.fd');template=sha(fw/'vars.fd')
with tempfile.TemporaryDirectory(prefix='c6057-neg-') as tmp:
 endpoint=Path(tmp)/'qmp';cmd=[];old=previous['arguments'];i=0
 while i<len(old):
  arg=old[i]
  if arg=='-device' and old[i+1]=='ramfb' and label=='no-ramfb':i+=2;continue
  if arg=='-qmp':cmd += [arg,f'unix:{endpoint},server=on,wait=off'];i+=2;continue
  if arg=='-serial':cmd += [arg,f'file:{out/"serial.log"}'];i+=2;continue
  if arg.startswith('node-name=pflash1,'):arg=f'node-name=pflash1,driver=file,filename={out/"vars.fd"}'
  cmd.append(arg);i+=1
 assert ('ramfb' in cmd)==(label=='ramfb');r['arguments']=cmd;(out/'launch.json').write_text(json.dumps(r,indent=2)+'\n');r['environment']=previous['environment'];r['emulator_version']=subprocess.check_output([qemu,'--version'],env=env,text=True);start=time.monotonic()
 with (out/'stderr.log').open('wb') as err:
  p=subprocess.Popen(cmd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=err)
  try:
   while p.poll() is None and time.monotonic()-start<45:
    text=(out/'serial.log').read_text(errors='replace') if (out/'serial.log').exists() else ''
    if 'CONDUIT_RISCV64_PRODUCT_REFUSAL ' in text or ('CONDUIT_RISCV64_PRODUCT ' in text and '"status":"ready"' in text):break
    time.sleep(.2)
   if p.poll() is None and endpoint.exists():
    with socket.socket(socket.AF_UNIX) as sock:
     sock.settimeout(5);sock.connect(str(endpoint));stream=sock.makefile('rwb');trace=[]
     def receive():
      line=stream.readline(16384);assert line and len(line)<16384;v=json.loads(line);trace.append(v);return v
     receive()
     def request(name,args=None):
      stream.write(json.dumps({'execute':name,**({'arguments':args} if args else {})}).encode()+b'\n');stream.flush()
      while True:
       v=receive()
       if 'return' in v or 'error' in v:return v
     request('qmp_capabilities');request('stop');r['screendump_result']=request('screendump',{'filename':str(out/'display.ppm')});(out/'qmp.json').write_text(json.dumps(trace,indent=2)+'\n')
  finally:
   if p.poll() is None:p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 r['exit_code']=p.returncode;r['elapsed_ms']=int((time.monotonic()-start)*1000)
assert sha(fw/'vars.fd')==template;r['template_vars_unchanged']=True
text=(out/'serial.log').read_text(errors='replace');r['serial_product_ready_observed']=('CONDUIT_RISCV64_PRODUCT ' in text and '"status":"ready"' in text);r['negative_no_display_observed']='error' in r.get('screendump_result',{})
r['files']=[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in out.iterdir() if f.is_file() and f.name!='vars.fd'];(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit_code','elapsed_ms','serial_product_ready_observed','negative_no_display_observed','screendump_result']},indent=2));print(text[-1300:])
