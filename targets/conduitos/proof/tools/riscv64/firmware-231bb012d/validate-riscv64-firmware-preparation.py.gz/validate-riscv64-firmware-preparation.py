from pathlib import Path
import os,subprocess,json,time,hashlib,sys
w=Path(__file__).resolve().parent;repo=w/'conduit';out=w/'riscv64-firmware-preparation-validation';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();cache=repo/'target/conduitos/toolchain/edk2-riscv64';assert not cache.exists()
r={'source':source,'commands':[],'initial_cache_absent':True,'scope':'firmware acquisition and local verification only; no guest execution or product frame'}
commands=[('missing-doctor',['cargo','xtask','make','conduitos','doctor-riscv64-firmware'],False),('cold',['cargo','xtask','make','conduitos','prepare-riscv64-firmware'],True),('warm',['cargo','xtask','make','conduitos','prepare-riscv64-firmware'],True),('doctor',['cargo','xtask','make','conduitos','doctor-riscv64-firmware'],True),('clippy',['cargo','clippy','--locked','-p','xtask','--all-targets','--','-D','warnings'],True),('preflight',['cargo','xtask','ci','pipeline','preflight'],True)]
for name,args,success in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as log:code=subprocess.run(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 r['commands'].append({'name':name,'command':args,'exit_code':code,'seconds':round(time.monotonic()-start,3)});(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(name,code,flush=True)
 if (code==0)!=success:sys.exit(1)
 if name=='missing-doctor':assert not cache.exists()
pin=json.loads((repo/'targets/conduitos/tools/riscv64-firmware/manifest.json').read_text());r['artifacts']=[]
for a in pin['files']:
 p=cache/a['name'];b=p.read_bytes();assert len(b)==a['bytes'] and hashlib.sha256(b).hexdigest()==a['sha256'];assert not p.stat().st_mode&0o222;r['artifacts'].append({'name':a['name'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'readonly':True})
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
r.update(status='passed',source_clean_unchanged=True);(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('firmware preparation validation passed',flush=True)
