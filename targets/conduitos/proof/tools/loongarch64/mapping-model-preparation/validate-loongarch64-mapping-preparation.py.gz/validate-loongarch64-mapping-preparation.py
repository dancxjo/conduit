from pathlib import Path
import os,subprocess,json,hashlib,time,sys
w=Path(__file__).resolve().parent;repo=w/'conduit-loongarch-prep';module=repo/'targets/conduitos/src/arch/loongarch64/framebuffer/mapping.rs';tests=module.with_name('mapping_tests.rs');serde=w/'conduit/target/debug/deps/libserde-16b0692fca7a1d2f.rlib';out=w/'loongarch64-mapping-preparation-validation';out.mkdir(exist_ok=False);binary=out/'mapping-tests';sources={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [module,tests]};receipt={'scope':'standalone pure mapping interpretation tests only; not integrated Cargo/normal product/firmware proof','source_files':sources,'serde_dependency_sha256':hashlib.sha256(serde.read_bytes()).hexdigest(),'commands':[]}
commands=[('format',['rustup','run','1.98.1','rustfmt','--edition','2024','--check',str(module),str(tests)]),('compile',['rustup','run','1.98.1','rustc','--edition=2024','--test',str(module),'--extern','serde='+str(serde),'-L','dependency='+str(serde.parent),'-o',str(binary)]),('tests',[str(binary),'--nocapture'])]
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('wb')as log:code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt['commands'].append({'name':name,'command':args,'exit_code':code,'seconds':round(time.monotonic()-start,3)});(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,code,flush=True)
 if code:sys.exit(code)
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in sources.items());receipt.update(status='passed',source_files_unchanged=True);(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
