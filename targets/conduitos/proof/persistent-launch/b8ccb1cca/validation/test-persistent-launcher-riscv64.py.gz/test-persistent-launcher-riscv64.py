from pathlib import Path
import os,subprocess,time,json,signal,hashlib
w=Path(__file__).resolve().parent;r=w/'conduit';out=w/'persistent-launcher-riscv64-validation';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',SDL_VIDEODRIVER='dummy',SDL_RENDER_DRIVER='software',CONDUITOS_AARCH64_FIRMWARE='/home/dancxjo/Documents/Codex/2026-10-13/goal-scan-the-open-conduit-issues/work/usb-aarch64-tools/extracted/usr/share/qemu-efi-aarch64/QEMU_EFI.fd');env['PATH']=str(w/'tools/bin')+':'+env['PATH']
receipt={'scope':'persistent launcher hosted tests and supervised normal RISC-V product session with SDL dummy backend, no human/physical/interactive-input acceptance','commands':[]}
for name,args in [('help',['cargo','xtask','make','host','launch','--help'])]:
 start=time.monotonic()
 with(out/(name+'.log')).open('wb')as log:code=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 receipt['commands'].append({'name':name,'command':args,'exit_code':code,'seconds':round(time.monotonic()-start,3)});(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(name,code,flush=True)
 if code:raise SystemExit(code)
product=r/'target/host-build/6057-riscv64-graphical-61084bb3a';manifest=json.loads((product/'build-manifest.json').read_text());image=product/manifest['image']['file'];before=hashlib.sha256(image.read_bytes()).hexdigest();assert before==manifest['image']['sha256']
args=['cargo','xtask','make','host','launch',str(product)];started=time.monotonic();ready=None;guest=None
with(out/'session.log').open('wb')as log:
 p=subprocess.Popen(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while time.monotonic()-started<90:
   if p.poll()is not None:break
   text=(out/'session.log').read_text(errors='replace')
   if 'CONDUIT_RISCV64_PRODUCT 'in text and 'CONDUIT_FIRMWARE_FACE 'in text:
    if ready is None:ready=time.monotonic()
    if time.monotonic()-ready>=3:break
   time.sleep(.1)
  assert ready is not None,'normal graphical product did not reach ready'
  assert p.poll()is None and time.monotonic()-ready>=3,'launcher did not remain live after ready'
  for proc in Path('/proc').iterdir():
   if proc.name.isdigit():
    try:
     if os.getpgid(int(proc.name))==p.pid and (proc/'comm').read_text().strip().startswith('qemu-system'):
      assert guest is None;guest=int(proc.name)
    except (FileNotFoundError,ProcessLookupError,PermissionError):pass
  assert guest is not None
  receipt['session']={'command':args,'product_source':manifest['source_identity'],'image_sha256':before,'product_ready_observed':True,'firmware_face_observed':True,'still_running_after_ready_ms':int((time.monotonic()-ready)*1000),'supervisor_stop':'SIGTERM sent only to owned QEMU child after live assertion','dummy_backend':True}
  os.kill(guest,signal.SIGTERM);code=p.wait(timeout=10);receipt['session']['launcher_exit_code']=code
 finally:
  if p.poll()is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
assert hashlib.sha256(image.read_bytes()).hexdigest()==before
receipt.update(status='passed',image_unchanged=True);(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('persistent session',code,flush=True)
