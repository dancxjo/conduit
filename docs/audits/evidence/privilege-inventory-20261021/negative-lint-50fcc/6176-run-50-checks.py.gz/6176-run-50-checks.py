import subprocess,os,json,time
from pathlib import Path
root=Path("/home/dancxjo/Documents/Codex/2026-10-21/please-finish-and-close-any-conduit")
cwd=root/"work/6179-startup"
source="50fcc74e8b8872f9d7afd49df9482a4d98782916"
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=cwd,text=True).strip()==source
assert not subprocess.check_output(["git","status","--porcelain"],cwd=cwd,text=True)
env=os.environ.copy();env.update(CARGO_TARGET_DIR="/home/dancxjo/Documents/Codex/2026-10-21/goal-find-the-first-available-github/work/lint-target",CARGO_BUILD_JOBS="4",CARGO_INCREMENTAL="0",CARGO_PROFILE_DEV_DEBUG="0",CONDUIT_CONDUITOS_TARGET_ROOT=str(root/"work/6176-50fcc-normal-target"))
steps=[("focused-tests",["cargo","+stable","xtask","check","privilege-inventory"]),("strict-clippy",["cargo","+stable","clippy","--locked","-p","xtask","--all-targets","--","-D","warnings"]),("fmt",["cargo","+stable","fmt","--all","--","--check"]),("normal-build",["cargo","+stable","xtask","make","host","build","targets/conduitos/profiles/conduitos-native.host.conduit","--output",str(root/"work/6176-50fcc-normal-product"),"--locked"])]
receipt={"source_commit":source,"steps":[],"status":"running"}
out=root/"work/6176-50fcc-checks.json"
for name,cmd in steps:
 log=root/("work/6176-50fcc-"+name+".log");assert not log.exists()
 print("START",name,flush=True);start=time.monotonic()
 with log.open("wb") as f: result=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt["steps"].append({"name":name,"command":cmd,"exit_code":result.returncode,"elapsed_seconds":time.monotonic()-start,"log":str(log)})
 receipt["status"]="failed" if result.returncode else "running";out.write_text(json.dumps(receipt,indent=2)+"\n")
 print("END",name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
receipt["status"]="complete";out.write_text(json.dumps(receipt,indent=2)+"\n")
