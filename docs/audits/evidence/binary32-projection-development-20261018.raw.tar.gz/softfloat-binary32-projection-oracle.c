#include <inttypes.h>
#include <stdio.h>
#include "softfloat.h"
static uint64_t state = UINT64_C(0x63e2d9a48b175fc0);
static uint64_t random_word(void) {
    state ^= state << 13; state ^= state >> 7; state ^= state << 17; return state;
}
static void emit(uint64_t hi, uint64_t lo) {
    const uint_fast8_t modes[] = {softfloat_round_near_even, softfloat_round_minMag,
        softfloat_round_max, softfloat_round_min};
    for (unsigned sign = 0; sign < 2; ++sign) for (unsigned mode = 0; mode < 4; ++mode) {
        float128_t source = {{lo, hi | ((uint64_t)sign << 63)}};
        softfloat_roundingMode = modes[mode]; softfloat_exceptionFlags = 0;
        float32_t target = f128_to_f32(source);
        printf("%016" PRIx64 " %016" PRIx64 " %u %08" PRIx32 " %u\n",
            source.v[1], source.v[0], mode, target.v, (unsigned)softfloat_exceptionFlags);
    }
}
int main(void) {
    puts("# SoftFloat a0c6494cdc11865811dec815d5c0049fba9d82a8 f128_to_f32; hi lo mode target flags");
    softfloat_detectTininess = softfloat_tininess_afterRounding;
    /* Exact midpoint and +/-2^-100 around it: a binary64 detour loses the side. */
    emit(UINT64_C(0x3fff000001000000), 0);
    emit(UINT64_C(0x3fff000001000000), UINT64_C(0x1000));
    emit(UINT64_C(0x3fff000000ffffff), UINT64_C(0xfffffffffffff000));
    /* Min-normal, half-min-subnormal, and finite overflow boundaries. */
    const int powers[] = {-151, -150, -149, -148, -127, -126, -125, 0, 126, 127, 128};
    for (unsigned n = 0; n < sizeof powers / sizeof *powers; ++n) {
        uint64_t exponent = (uint64_t)(16383 + powers[n]) << 48;
        emit(exponent, 0);
        emit(exponent | UINT64_C(0x0000ffffffffffff), UINT64_MAX);
    }
    for (unsigned n = 0; n < 512; ++n) {
        int exponent = -152 + (int)(random_word() % 280);
        uint64_t hi = ((uint64_t)(16383 + exponent) << 48) | (random_word() & UINT64_C(0x0000ffffffffffff));
        emit(hi, random_word());
    }
    return 0;
}
