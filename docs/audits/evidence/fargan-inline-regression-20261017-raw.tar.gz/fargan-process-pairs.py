#!/usr/bin/env python3
"""Alternate exact committed prebuilt workers; retain all process results."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
work=Path(__file__).resolve().parent
fixture=work/'fargan-development/fixture'
config={
 'before':{'cwd':work/'fargan-graph','worker':work/'fargan-workers/before-4039','receipt':work/'fargan-workers/before-4039-build.json','conformance':work/'fargan-baseline-4039-01'},
 'after':{'cwd':work/'fargan-after-replay','worker':work/'fargan-workers/after-739938','receipt':work/'fargan-workers/after-739938-build.json','conformance':work/'fargan-after-739938-01'},
}
spec=importlib.util.spec_from_file_location('verifier',work/'fargan-graph/proof/performance/verify-fargan.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)

def git(cwd,*args):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
reports=[]
for pair in range(3):
 results={}
 for mode in (['before','after'] if pair%2==0 else ['after','before']):
  c=config[mode];receipt=json.loads(c['receipt'].read_text());source=receipt['source']
  if git(c['cwd'],'rev-parse','HEAD')!=source or git(c['cwd'],'status','--porcelain'):raise RuntimeError('unfrozen source')
  if sha(c['worker'])!=receipt['binary_sha256']:raise RuntimeError('worker changed')
  output=work/f'fargan-process-pair-{pair:02}-{mode}';output.mkdir()
  shutil.copyfile(c['receipt'],output/'worker-build.json')
  for name in ['conformance.stdout.log','conformance.stderr.log']:shutil.copyfile(c['conformance']/name,output/name)
  command=['taskset','-c','1',str(c['worker']),str(fixture),str(output),'2']
  print(f'start pair={pair} mode={mode} source={source}',flush=True)
  with (output/'stdout.log').open('wb') as stdout,(output/'stderr.log').open('wb') as stderr:
   status=subprocess.run(command,cwd=c['cwd'],stdout=stdout,stderr=stderr)
  final=git(c['cwd'],'rev-parse','HEAD');clean=not git(c['cwd'],'status','--porcelain')
  hashes={str(p.relative_to(output)):sha(p) for p in output.rglob('*') if p.is_file()}
  report={'schema':'conduit.fargan-runtime-performance-command@1','git_sha':source,'final_git_sha':final,
   'source_custody_verified':final==source and clean,'conformance_success':receipt['conformance_success'],
   'worker_success':status.returncode==0,'worker_exit_code':status.returncode,'repetitions':2,
   'artifact_sha256':hashes,'command':command,'prebuilt_worker_sha256':receipt['binary_sha256'],
   'proof_scope':'Independent process replay of exact committed worker already built and conformance-tested through xtask; no source or implementation substitution.'}
  (output/'status.json').write_text(json.dumps(report,indent=2)+'\n')
  results[mode]=v.verify(output)
  print(f'validated pair={pair} mode={mode} frames={len(results[mode]["rows"])}',flush=True)
 comparison=v.compare(results['before'],results['after']);reports.append(comparison)
 (work/f'fargan-process-pair-{pair:02}-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
 print(f'pair={pair} ratios={json.dumps(comparison["ratios"])}',flush=True)
(work/'fargan-process-pairs-comparisons.json').write_text(json.dumps(reports,indent=2)+'\n')
