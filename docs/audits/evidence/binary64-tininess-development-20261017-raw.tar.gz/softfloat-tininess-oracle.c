#include <inttypes.h>
#include <stdio.h>
#include "softfloat.h"

int main(void) {
    const uint_fast8_t modes[] = {softfloat_round_near_even, softfloat_round_minMag,
        softfloat_round_max, softfloat_round_min};
    softfloat_detectTininess = softfloat_tininess_afterRounding;
    for (unsigned negative = 0; negative < 2; ++negative) {
        for (unsigned m = 0; m < 4; ++m) {
            const float64_t a = {UINT64_C(0x0010000000000000) | ((uint64_t)negative << 63)};
            const float64_t b = {UINT64_C(0x3fefffffffffffff)};
            softfloat_roundingMode = modes[m];
            softfloat_exceptionFlags = 0;
            const float64_t result = f64_mul(a, b);
            printf("sign=%u mode=%u result=%016" PRIx64 " flags=%u\n",
                negative, m, result.v, (unsigned)softfloat_exceptionFlags);
        }
    }
    /* Exact binary128 sources: min-normal minus 2^(-1075-offset).
       The binary128 significand represents all three boundary probes exactly. */
    const uint64_t tails[] = {UINT64_C(0xf000000000000000),
        UINT64_C(0xf800000000000000), UINT64_C(0xfc00000000000000)};
    for (unsigned offset = 0; offset < 3; ++offset) {
        for (unsigned negative = 0; negative < 2; ++negative) {
            for (unsigned m = 0; m < 4; ++m) {
                const float128_t source = {{tails[offset], UINT64_C(0x3c00ffffffffffff) | ((uint64_t)negative << 63)}};
                softfloat_roundingMode = modes[m];
                softfloat_exceptionFlags = 0;
                const float64_t result = f128_to_f64(source);
                printf("distance=2^-%u sign=%u mode=%u result=%016" PRIx64 " flags=%u\n",
                    1075 + offset, negative, m, result.v, (unsigned)softfloat_exceptionFlags);
            }
        }
    }
    return 0;
}
