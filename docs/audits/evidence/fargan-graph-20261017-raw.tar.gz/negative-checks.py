#!/usr/bin/env python3
"""Refusal replay against a completed retained capture, without changing it."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
sys.dont_write_bytecode = True
repo, original, destination = map(Path, sys.argv[1:])
spec = importlib.util.spec_from_file_location('fargan_verifier',repo/'proof/performance/verify-fargan.py')
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)

def json_change(root,name,change):
    path=root/name
    value=json.loads(path.read_text());change(value);path.write_text(json.dumps(value))

def raw_change(root,change):
    path=root/'raw.jsonl';rows=[json.loads(line) for line in path.read_text().splitlines()]
    change(rows);path.write_text(''.join(json.dumps(r)+'\n' for r in rows))

def play(rows):
    return next(row for row in rows if row.get('phase')=='fargan-frame-play')

def resign(root):
    status=json.loads((root/'status.json').read_text())
    status['artifact_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in root.rglob('*') if p.is_file() and p.name!='status.json'}
    (root/'status.json').write_text(json.dumps(status))

cases=[
 ('corrupt-artifact',lambda r:(r/'source.conduit').write_text('corrupt'),False),
 ('wrong-model',lambda r:json_change(r,'model-profile.json',lambda j:j.update(f32_bundle_sha256='0'*64)),True),
 ('Play-allocation',lambda r:raw_change(r,lambda rows:play(rows)['allocator'].update(allocations=1)),True),
 ('bad-phase-partition',lambda r:raw_change(r,lambda rows:play(rows).update(step_remainder_ns=0)),True),
 ('incomplete-frame-coverage',lambda r:raw_change(r,lambda rows:rows.pop()),True),
 ('undrained-Play',lambda r:raw_change(r,lambda rows:play(rows).update(structural_drain=False)),True),
 ('source-custody',lambda r:json_change(r,'status.json',lambda j:j.update(final_git_sha='0'*40)),True),
 ('wrong-Plan',lambda r:raw_change(r,lambda rows:play(rows).update(plan_sha256='0'*64)),True),
 ('changed-Sign-trace',lambda r:(r/'signs-first-frame.txt').write_text('wrong trace\n'),True),
 ('repeat-output-mismatch',lambda r:raw_change(r,lambda rows:next(x for x in rows if x.get('phase')=='fargan-frame-play' and x['repetition']==1 and x['frame']==0).update(output_sha256='0'*64)),True),
]
report=[]
for name,mutate,update_manifest in cases:
    with tempfile.TemporaryDirectory(prefix='fargan-refusal-',dir=original.parent) as directory:
        root=Path(directory)/'capture';shutil.copytree(original,root);mutate(root)
        if update_manifest:resign(root)
        try:verifier.verify(root)
        except ValueError as error:report.append({'case':name,'refused':True,'reason':str(error)})
        else:raise AssertionError('accepted corrupted '+name)
destination.write_text(json.dumps({'schema':'conduit.fargan-negative-replay@1','cases':report},indent=2)+'\n')
print(json.dumps({'corruptions_refused':len(report),'all_refused':True}))
