from pathlib import Path
import os,subprocess,time,json,hashlib,shutil,sys
sys.dont_write_bytecode=True
w=Path(__file__).resolve().parent;cwd=w/'fargan-boxed-before';target=w/'fargan-graph/target'
while Path('/proc/2308299/stat').exists() and Path('/proc/2308299/stat').read_text().split(') ')[1].split()[0]!='Z':time.sleep(5)
comparison=json.loads((w/'fargan-boxed-comparison.json').read_text());ratio=comparison['ratios']['wall_ns']['after_over_before']
print('boxed whole-Play ratio='+str(ratio),flush=True)
if ratio<1.03:
 print('No additional isolation automatically requested at this diagnostic threshold; independent profile replay remains necessary.',flush=True);sys.exit(0)
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(target);env['CARGO_BUILD_JOBS']='2';env['CARGO_INCREMENTAL']='0'
for mode,source in [('counter-only','17909e925'),('wakes-only','40cc97159')]:
 subprocess.run(['git','switch','--detach',source],cwd=cwd,check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True).strip()
 output=w/('fargan-'+mode+'-01');command=['taskset','-c','1','cargo','xtask','prove','runtime-performance','--fargan-fixture',str(w/'fargan-development/fixture'),'--output',str(output),'--repetitions','2']
 print('start '+mode,flush=True)
 with (w/('fargan-'+mode+'-command.log')).open('wb') as log:subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 binary=target/'release/examples/fargan_performance';copy=w/('fargan-workers/'+mode);shutil.copyfile(binary,copy);copy.chmod(0o755)
 receipt={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip(),'binary_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'conformance_success':True,'capture':str(output),'compilation_path':str(cwd),'command':command}
 (w/('fargan-workers/'+mode+'-build.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 with (w/('fargan-'+mode+'-comparison.json')).open('w') as log:subprocess.run(['python3',str(w/'fargan-review/proof/performance/verify-fargan.py'),str(output),'--before',str(w/'fargan-boxed-before-01')],stdout=log,check=True)
 print('verified '+mode,flush=True)
