from pathlib import Path
import os,subprocess,time,json,hashlib
w=Path(__file__).resolve().parent
while subprocess.run(['kill','-0','2293310'],stderr=subprocess.DEVNULL).returncode==0: time.sleep(5)
print('inline replay finished; starting boxed diagnostic',flush=True)
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(w/'fargan-graph/target');env['CARGO_BUILD_JOBS']='2';env['CARGO_INCREMENTAL']='0'
for mode in ['before','after']:
 cwd=w/('fargan-boxed-'+mode);out=w/('fargan-boxed-'+mode+'-01')
 command=['taskset','-c','1','cargo','xtask','prove','runtime-performance','--fargan-fixture',str(w/'fargan-development/fixture'),'--output',str(out),'--repetitions','2']
 print('start '+mode,flush=True)
 with (w/('fargan-boxed-'+mode+'-command.log')).open('wb') as log:
  subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 binary=w/'fargan-graph/target/release/examples/fargan_performance';copy=w/('fargan-workers/boxed-'+mode)
 import shutil
 shutil.copyfile(binary,copy);copy.chmod(0o755)
 receipt={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip(),'binary_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'conformance_success':True,'capture':str(out),'command':command}
 (w/('fargan-workers/boxed-'+mode+'-build.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print('completed '+mode,flush=True)
subprocess.run(['python3',str(w/'fargan-review/proof/performance/verify-fargan.py'),str(w/'fargan-boxed-after-01'),'--before',str(w/'fargan-boxed-before-01')],stdout=(w/'fargan-boxed-comparison.json').open('w'),check=True)
