//! Diagnostic producer for the existing installed expression alternatives.
//! This is not the completed #5568 measurement/decision acceptance worker.
#[path = "../tests/replan_common/expression.rs"]
#[allow(dead_code)]
mod fixture;
use conduit_core::OfferGeneration;
use conduit_std_host::StdHostConfig;
use serde_json::json;
use std::{error::Error, fs, io::Write, path::PathBuf, process::Command};
fn tick() -> Result<u64, Box<dyn Error>> {
    #[cfg(target_os = "linux")]
    {
        let mut time = libc::timespec {
            tv_sec: 0,
            tv_nsec: 0,
        };
        if unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut time) } != 0 {
            return Err("clock unavailable".into());
        }
        Ok(u64::try_from(time.tv_sec)?
            .checked_mul(1_000_000_000)
            .and_then(|s| s.checked_add(u64::try_from(time.tv_nsec).ok()?))
            .ok_or("clock overflow")?)
    }
    #[cfg(not(target_os = "linux"))]
    Err("diagnostic requires Linux CLOCK_MONOTONIC".into())
}
fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    if args.len() != 2 || args[1] != "--diagnostic" {
        return Err(
            "internal diagnostic: output-file --diagnostic; not an acceptance measurement".into(),
        );
    }
    let path = PathBuf::from(&args[0]);
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    let id = format!("{}/{}", std::process::id(), tick()?);
    let mut families = Vec::with_capacity(2);
    for (local, profile) in [(false, "scalar-tape"), (true, "local")] {
        let mut case = fixture::case_with_profile(
            StdHostConfig {
                host_id: format!("host/replan/{id}/{profile}").into(),
                boot_id: format!("boot/replan/{id}/{profile}").into(),
                offer_generation: OfferGeneration(1),
            },
            local,
        );
        let inputs = fixture::inputs(7);
        let mut rows = Vec::with_capacity(10);
        for round in 0..5 {
            for tape in if round % 2 == 0 {
                [false, true]
            } else {
                [true, false]
            } {
                let plan = if tape {
                    &case.candidate
                } else {
                    &case.previous
                };
                let mut outputs = fixture::Outputs::default();
                let started = tick()?;
                let report = case.host.run_external_plot_to(
                    plan.fragments[0].clone(),
                    &inputs,
                    &mut outputs,
                    &mut std::io::sink(),
                    &mut fixture::NoTimer,
                )?;
                let completed = tick()?;
                if outputs.0.len() != 1 || &*outputs.0[0].bytes != 231u64.to_le_bytes().as_slice() {
                    return Err("differential output differs".into());
                }
                let kernel = report.kernel.as_ref().ok_or("missing kernel")?;
                if kernel.value_allocation_capacity_before != kernel.value_allocation_capacity_after
                {
                    return Err("Value store grew during Play".into());
                }
                rows.push(json!({"round":round,"profile":if tape {profile} else {"generic"},"plan_id":plan.plan_id,
                "started_tick":started.to_string(),"completed_tick":completed.to_string(),"elapsed_ns":(completed-started).to_string(),
                "active_play":kernel.active_play,"kernel_sign":kernel.kernel_sign.iter().map(|e| {let conduit_kernel::KernelEvent {sequence,node,port,request,kind}=e;json!({"sequence":sequence,"node":node.0,"port":port.map(|p|p.0),"request":request.map(|r|r.0),"kind":format!("{kind:?}")})}).collect::<Vec<_>>(),"observations":report.observations,
                "value_capacity_before":kernel.value_allocation_capacity_before,"value_capacity_after":kernel.value_allocation_capacity_after,
                "output_bytes":outputs.0[0].bytes}));
            }
        }
        families.push(json!({"candidate_profile":profile,"source_document":case.previous.source_document_id,"host":case.host.advertisement(),"previous_plan":case.previous,"candidate_plan":case.candidate,"input_bytes":inputs[0].bytes,"rows":rows}));
    }
    let git = |args: &[&str]| -> Result<String, Box<dyn Error>> {
        let out = Command::new("git").args(args).output()?;
        if !out.status.success() {
            return Err("git probe failed".into());
        }
        Ok(String::from_utf8(out.stdout)?.trim().into())
    };
    let value = json!({"schema":"conduit.reluctant-replan-diagnostic@1","diagnostic_only":true,"debug_build":cfg!(debug_assertions),"source":git(&["rev-parse","HEAD"])?,"dirty":!git(&["status","--porcelain"])?.is_empty(),
        "clock":"Linux CLOCK_MONOTONIC; quantization/statistical uncertainty not admitted as a forecast here",
        "scope":"one retained Std Host, ordinary per-call kernel preparation/execution/output acceptance; not complete owner lifetime or policy admission proof",
        "families":families});
    file.write_all(&serde_json::to_vec_pretty(&value)?)?;
    Ok(())
}
