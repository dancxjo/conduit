plot baseline (
 >> input: Text...|
 output0: Text...| >>
 output1: Text...| >>
 output2: Text...| >>
 output3: Text...| >>
) {
 input >> (.) >> output0
 input >> (.) >> output1
 input >> (.) >> output2
 input >> (.) >> output3
}
