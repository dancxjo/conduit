# The pitch law is ordinary Conduitese. Convert distance to a dimensionless
# number of centimetres, then lower pitch by 55 Hz per centimetre. Clamping is
# explicit; unit conversion and arithmetic never silently round.
plot theremin-pitch (
    >> distance: Distance
    frequency: Frequency >>
) = (distance <= 0cm ? 1760Hz : distance >= 30cm ? 110Hz : 1760Hz - (distance / 1cm) * 55Hz)

plot baseline (
 >> input: Distance...|
 output: Frequency...| >>
) {
 input >> ((. <= 0cm ? 1760Hz : . >= 30cm ? 110Hz : 1760Hz - (. / 1cm) * 55Hz)) >> output
}
