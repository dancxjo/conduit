plot baseline (
 input: Scalar >> output: Bool
) {
 input >> (. > 1) >> output
}
