plot baseline (
 input: Scalar >> output: Scalar
) {
 input >> (. > 1 ? . + 1 : . + 2) >> output
}
