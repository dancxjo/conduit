plot baseline (
 input: Scalar >> output: Scalar
) {
 input >> (. + 1) >> output
}
