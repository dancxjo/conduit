plot baseline (
 input: U64 >> output: Bool
) {
 input >> (. > 1) >> output
}
