plot baseline (
 input: U64 >> output: U64
) {
 input >> (. + 1) >> output
}
