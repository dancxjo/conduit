plot numerics (
 exact: NumericalResult <= 8192B >>
 loose: NumericalResult <= 8192B >>
) {
 precise: math/realize(request={value:0.3,maximum-error:0})
 approximate: math/realize(request={value:0.3,maximum-error:1})
 precise.result >> exact
 approximate.result >> loose
}
