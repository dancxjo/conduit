# The pitch law is ordinary Conduitese. Convert distance to a dimensionless
# number of centimetres, then lower pitch by 55 Hz per centimetre. Clamping is
# explicit; unit conversion and arithmetic never silently round.
plot theremin-pitch (
    >> distance: Distance
    frequency: Frequency >>
) = (distance <= 0cm ? 1760Hz : distance >= 30cm ? 110Hz : 1760Hz - (distance / 1cm) * 55Hz)

# The one canonical Theremin. Both controls describe portable meaning. Hosts
# own acquisition, cadence, and playback; this Plot owns the instrument law.
plot pocket-theremin (
    >> pitch-distance: Distance
    >> volume: Scalar
    >> cadence: value/tick@1...
    audio: audio/pcm-frames@1...| >>
) {
    pitch: theremin-pitch
    frequency: keep Frequency(440Hz) for this play
    tone: audio/continuous-tone
    gain: audio/apply-gain

    pitch-distance >> pitch.distance
    pitch.frequency >> frequency
    frequency >> tone.frequency
    cadence >> tone.cadence
    tone.audio >> gain.source-audio
    volume >> gain.amplitude
    gain.audio >> audio
}

plot theremin-distance (
    >> position: Scalar
    distance: Distance >>
) = (position * 30cm)

# A controller binding, not another Theremin. It adapts a normalized two-axis
# surface to the canonical Plot and selects browser audio playback.
plot phone-two-axis-controller {
    controller: input/pointer-source
    x-normalize: math/normalized-ratio-scalar
    y-normalize: math/normalized-ratio-scalar
    distance: theremin-distance
    cadence: time/every(freq = 40ms)
    instrument: pocket-theremin
    play: audio/continuous-play

    controller.pointer >> project(PointerEvent.position) >> project(InputSurfacePoint.x) >> x-normalize.in
    controller.pointer >> project(PointerEvent.position) >> project(InputSurfacePoint.y) >> y-normalize.in
    x-normalize.out >> distance.position
    distance.distance >> instrument.pitch-distance
    y-normalize.out >> instrument.volume
    cadence.tick >> instrument.cadence
    instrument.audio >> play.audio
}
