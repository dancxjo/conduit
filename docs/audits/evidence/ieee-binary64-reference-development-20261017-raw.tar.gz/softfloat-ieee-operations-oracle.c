#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include "softfloat.h"

int main(void) {
    const uint64_t values[] = {
        0, UINT64_C(0x8000000000000000), UINT64_C(0x3ff0000000000000),
        UINT64_C(0xbff0000000000000), UINT64_C(0x4008000000000000),
        1, UINT64_C(0x8000000000000001), UINT64_C(0x000fffffffffffff),
        UINT64_C(0x0010000000000000), UINT64_C(0x0010000000000001),
        UINT64_C(0x7fefffffffffffff), UINT64_C(0xffefffffffffffff),
        UINT64_C(0x7ff0000000000000), UINT64_C(0xfff0000000000000),
        UINT64_C(0x7ff8000000000042), UINT64_C(0xfff0000000000069),
        UINT64_C(0x3fb999999999999a), UINT64_C(0x3fc999999999999a),
        UINT64_C(0x3fefffffffffffff), UINT64_C(0x3ff0000000000001)
    };
    const uint_fast8_t modes[] = {softfloat_round_near_even, softfloat_round_minMag,
        softfloat_round_max, softfloat_round_min};
    float64_t (*const operations[])(float64_t,float64_t) = {f64_add,f64_sub,f64_mul,f64_div};
    const unsigned count = sizeof(values)/sizeof(values[0]);
    softfloat_detectTininess = softfloat_tininess_afterRounding;
    puts("# SoftFloat a0c6494cdc11865811dec815d5c0049fba9d82a8, 8086-SSE, tininess after rounding");
    puts("# a: add/sub/mul/div; c: eq/lt_quiet/le_quiet/unordered; modes: nearest/zero/positive/negative");
    puts("# class operation mode left-bits right-bits result-bits flags");
    for (unsigned i=0; i<count; ++i) for (unsigned j=0; j<count; ++j) {
        const float64_t a = {values[i]}, b = {values[j]};
        for (unsigned operation=0; operation<4; ++operation) {
            for (unsigned mode=0; mode<4; ++mode) {
                softfloat_roundingMode = modes[mode];
                softfloat_exceptionFlags = 0;
                const float64_t result = operations[operation](a,b);
                printf("a %u %u %016" PRIx64 " %016" PRIx64 " %016" PRIx64 " %u\n",
                    operation, mode, a.v, b.v, result.v, (unsigned)softfloat_exceptionFlags);
            }
            softfloat_exceptionFlags = 0;
            bool result;
            switch (operation) {
                case 0: result=f64_eq(a,b); break;
                case 1: result=f64_lt_quiet(a,b); break;
                case 2: result=f64_le_quiet(a,b); break;
                default: {
                    const bool a_ordered=f64_eq(a,a);
                    const bool b_ordered=f64_eq(b,b);
                    result=!(a_ordered && b_ordered);
                    break;
                }
            }
            printf("c %u 0 %016" PRIx64 " %016" PRIx64 " %016" PRIx64 " %u\n",
                operation, a.v, b.v, (uint64_t)result, (unsigned)softfloat_exceptionFlags);
        }
    }
    return 0;
}
