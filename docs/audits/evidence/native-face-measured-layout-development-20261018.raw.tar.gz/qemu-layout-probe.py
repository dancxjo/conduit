import sys,pathlib,subprocess,socket,time,json,os,hashlib
width,height=map(int,sys.argv[1:3]);image=pathlib.Path(sys.argv[3]).resolve();out=pathlib.Path(sys.argv[4]).resolve();out.mkdir(parents=True,exist_ok=True)
monitor=pathlib.Path(f'/tmp/conduit-layout-probe-{os.getpid()}.sock');serial=out/'serial.log';capture=out/'front-door.ppm'
args=['qemu-system-x86_64','-M','q35','-cpu','max','-m','512M','-smp','1','-display','none','-vga','std','-global',f'VGA.xres={width}','-global',f'VGA.yres={height}','-monitor','none','-qmp',f'unix:{monitor},server=on,wait=off','-serial',f'file:{serial}','-no-reboot','-net','none','-device','qemu-xhci,id=conduitos-xhci,p2=3,p3=0','-device','usb-kbd,id=conduitos-keyboard,bus=conduitos-xhci.0,port=1','-device','usb-mouse,id=conduitos-pointer,bus=conduitos-xhci.0,port=2','-cdrom',str(image),'-boot','d']
record={'proof_class':'freestanding-emulator viewport probe, not full supported journey','image_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'requested_extent':[width,height],'qemu_argv':args,'transcript':[],'status':'running'}
child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=(out/'qemu-stderr.log').open('wb'))
conn=None
try:
 deadline=time.monotonic()+3
 while not monitor.exists():
  if child.poll() is not None:raise RuntimeError('guest process exited before QMP')
  if time.monotonic()>deadline:raise TimeoutError('QMP socket absent')
  time.sleep(.01)
 conn=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);conn.settimeout(3);conn.connect(str(monitor));reader=conn.makefile('rb')
 record['transcript'].append({'received':json.loads(reader.readline())})
 def command(name,arguments=None):
  req={'execute':name,'id':str(len(record['transcript']))}
  if arguments is not None:req['arguments']=arguments
  record['transcript'].append({'sent':req});conn.sendall(json.dumps(req).encode()+b'\n')
  for _ in range(16):
   line=reader.readline(16385)
   if len(line)>16384:raise RuntimeError('QMP message bound')
   response=json.loads(line);record['transcript'].append({'received':response})
   if response.get('id')==req['id']:
    if 'error'in response:raise RuntimeError(str(response['error']))
    return response
  raise RuntimeError('QMP event bound')
 command('qmp_capabilities')
 deadline=time.monotonic()+55
 while True:
  if child.poll() is not None:raise RuntimeError('guest exited before arrival')
  data=serial.read_bytes() if serial.exists() else b''
  if len(data)>16*1024*1024:raise RuntimeError('serial bound')
  if b'CONDUIT_BOOT_STAGE front-door-ready' in data:break
  if time.monotonic()>deadline:raise TimeoutError('front-door checkpoint missing')
  time.sleep(.02)
 record['observed_checkpoint']='CONDUIT_BOOT_STAGE front-door-ready';record['serial_byte_end']=len(data)
 command('screendump',{'filename':str(capture)})
 with capture.open('rb')as file:
  assert file.readline().strip()==b'P6'
  dimensions=file.readline()
  while dimensions.startswith(b'#'):dimensions=file.readline()
  record['actual_extent']=list(map(int,dimensions.split()));assert file.readline().strip()==b'255'
 record['capture_sha256']=hashlib.sha256(capture.read_bytes()).hexdigest();record['extent_matches_request']=record['actual_extent']==record['requested_extent'];record['status']='captured' if record['extent_matches_request'] else 'extent-mismatch'
 from PIL import Image
 Image.open(capture).save(out/'front-door.png')
 if len(sys.argv)>5 and sys.argv[5]=='reading' and record['extent_matches_request']:
  record['reading_stages']=[]
  for label,key in [('details','f2'),('details-next','pgdn'),('return-primary','f2')]:
   before=serial.read_bytes().count(b'CONDUIT_CRECHE_CHECKPOINT edited')
   event=lambda down:{'events':[{'type':'key','data':{'down':down,'key':{'type':'qcode','data':key}}}]}
   command('input-send-event',event(True))
   try:
    deadline=time.monotonic()+20
    while serial.read_bytes().count(b'CONDUIT_CRECHE_CHECKPOINT edited')<=before:
     if child.poll()is not None:raise RuntimeError('guest exited during reading')
     if time.monotonic()>deadline:raise TimeoutError(f'{label}: guest did not acknowledge reading change')
     time.sleep(.02)
   finally:command('input-send-event',event(False))
   stage=out/f'{label}.ppm';command('screendump',{'filename':str(stage)})
   picture=Image.open(stage);assert list(picture.size)==record['actual_extent'];picture.save(out/f'{label}.png')
   data=serial.read_bytes();records=[json.loads(line.split(b' ',1)[1])for line in data.splitlines()if line.startswith(b'CONDUIT_PRODUCT_JOURNEY ')]
   record['reading_stages'].append({'label':label,'key':key,'guest_checkpoint':'CONDUIT_CRECHE_CHECKPOINT edited','serial_byte_end':len(data),'capture_sha256':hashlib.sha256(stage.read_bytes()).hexdigest(),'guest_record':records[-1]if records else None})
  record['reading_completed']=True
 command('quit');child.wait(timeout=5)
except Exception as error:
 record['failure']=str(error);record['status']='refused'
finally:
 if child.poll() is None:child.terminate()
 try:child.wait(timeout=5)
 except subprocess.TimeoutExpired:child.kill();child.wait()
 record['process_stop']=child.returncode
 if conn:conn.close()
 monitor.unlink(missing_ok=True)
 (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({key:record.get(key)for key in['status','requested_extent','actual_extent','failure','process_stop']}))
