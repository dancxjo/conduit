use conduitos::{native_face_scene::NativeFaceScene, display::typography::TextLayout};
use conduit_face::{Face, GraphicsCommandKind, VisualExpression, VisualUserConstraints, admit_visual_expression};
use serde_json::json;
fn main() {
    let repo = std::env::args().nth(1).expect("repository");
    let mut records = Vec::new();
    for file in ["prebirth-face.json", "lulled-body-face.json", "awake-body-face.json", "open-domain-face.json", "home-audit-face.json"] {
        let path = if file == "home-audit-face.json" { format!("{repo}/../home-audit-face.json") } else { format!("{repo}/proof/conformance/face-waist/domain-derived/{file}") };
        let face: Face = serde_json::from_slice(&std::fs::read(path).unwrap()).unwrap();
        face.validate().unwrap();
        for (width, height) in [(1280,800),(640,480),(320,240)] {
            for scale in [100,200] {
                let expression = admit_visual_expression(Ok(VisualExpression::phosphor()), VisualUserConstraints {
                    forced_colors:false, reduced_motion:true, minimum_text_scale_percent:scale,
                    maximum_supported_text_scale_percent:200,
                }).unwrap();
                match NativeFaceScene::prepare_visual_fallback(face.clone(), width,height,true,&expression) {
                    Err(error) => records.push(json!({"specimen":file,"face_id":face.identity.as_str(),"width":width,"height":height,"scale":scale,"preparation_refusal":format!("{error:?}")})),
                    Ok(mut scene) => {
                        for details in [false,true] {
                            scene.show_details(details);
                            for page in 0..scene.pages() {
                            match scene.frame() {
                                Err(error) => records.push(json!({"specimen":file,"face_id":face.identity.as_str(),"width":width,"height":height,"scale":scale,"details":details,"frame_refusal":format!("{error:?}")})),
                                Ok(frame) => {
                                    let text: Vec<_> = frame.scene.commands().iter().filter(|c| c.kind == GraphicsCommandKind::Text).map(|c| {
                                        let measured = TextLayout::new_scaled(c.payload(),c.text_role().into(),c.bounds.width,scale).unwrap().finish_height();
                                        json!({"text":c.payload(),"role":format!("{:?}",c.text_role()),"bounds":{"x":c.bounds.x,"y":c.bounds.y,"width":c.bounds.width,"height":c.bounds.height},"measured_height":measured,"text_exceeds_bounds":measured > u32::from(c.bounds.height)})
                                    }).collect();
                                    records.push(json!({"specimen":file,"face_id":frame.face_id.as_str(),"revision":frame.revision,"width":width,"height":height,"scale":scale,"details":details,"page":page,"pages":frame.pages,"commands":frame.scene.commands().len(),"hits":frame.hits.len(),"text":text}));
                                }
                            }
                            scene.turn_page(true);
                            }
                        }
                    }
                }
            }
        }
    }
    println!("{}",json!({"proof_class":"CPU geometry fixture only; no QEMU or current owner grant","records":records}));
}
