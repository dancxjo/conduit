import hashlib, importlib.util, json, shutil, tempfile
from pathlib import Path
root = Path('work/conduit')
verifier = root/'proof/performance/verify-terminal-completion.py'
spec = importlib.util.spec_from_file_location('terminal_verifier',verifier)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
before=Path('work/terminal-before').resolve()
after=Path('work/terminal-after').resolve()
originals={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for d in [before,after] for p in d.iterdir() if p.is_file()}
results=[]
for case in ['artifact_hash','duplicate_sample','raw_report_mismatch','rehashed_sign_difference']:
 with tempfile.TemporaryDirectory(prefix='terminal-negative-',dir='work') as tmp:
  changed=Path(tmp)/'after'
  shutil.copytree(after,changed)
  path=changed/'report.json'
  report=json.loads(path.read_text())
  if case=='artifact_hash':
   path.write_text(path.read_text()+' ')
  else:
   if case=='duplicate_sample': report['rows'][-1]=report['rows'][0].copy()
   else: report['rows'][0]['events']='changed Sign trace'
   path.write_text(json.dumps(report)+'\n')
   if case=='rehashed_sign_difference':
    log=changed/'process-0.stdout.log'
    lines=log.read_text().splitlines()
    for index,line in enumerate(lines):
     if 'TERMINAL_COMPLETION_ROW ' in line:
      row=json.loads(line.split('TERMINAL_COMPLETION_ROW ',1)[1])
      row['events']='changed Sign trace'
      lines[index]='TERMINAL_COMPLETION_ROW '+json.dumps(row)
      break
    log.write_text('\n'.join(lines)+'\n')
   status=json.loads((changed/'status.json').read_text())
   for name in status['artifacts_sha256']:
    status['artifacts_sha256'][name]=hashlib.sha256((changed/name).read_bytes()).hexdigest()
   (changed/'status.json').write_text(json.dumps(status))
  try: module.compare(before,changed)
  except AssertionError as error: results.append({'case':case,'refused':True,'reason':str(error)})
  else: raise RuntimeError('accepted mutation '+case)
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in originals.items())
Path('work/terminal-verifier-negative.json').write_text(json.dumps({'verifier_sha256':hashlib.sha256(verifier.read_bytes()).hexdigest(),'originals_unchanged':True,'results':results},indent=2)+'\n')
print(results)
