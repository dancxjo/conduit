import hashlib,importlib.util,json,shutil,tempfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
w=Path(__file__).resolve().parent

def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
v=load('reserved',w/'fargan-boxed-after/proof/performance/verify-reserved-completion.py');reader=load('legacy',w/'fargan-boxed-after/proof/performance/verify-terminal-completion.py')
def read(p):return json.loads(p.read_text())
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
def resign(folder):
 status=read(folder/'status.json');status['artifacts_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file() and p.name!='status.json'};write(folder/'status.json',status)
def row_change(folder,fun):
 report=read(folder/'report.json');index=2;fun(report['rows'][index]);write(folder/'report.json',report)
 path=folder/'process-0.stdout.log';lines=path.read_text().splitlines();position=0
 for i,line in enumerate(lines):
  tag='TERMINAL_COMPLETION_ROW '
  if tag not in line:continue
  if position==index:
   prefix,body=line.split(tag,1);row=json.loads(body);fun(row);lines[i]=prefix+tag+json.dumps(row);break
  position+=1
 path.write_text('\n'.join(lines)+'\n')
results=[]
for case in ['wrong-hash','missing-artifact','duplicate-sample','rehashed-wrong-probe','rehashed-wrong-sign','rehashed-storage-growth','rehashed-allocation','native-word-lie','foreign-entrance','wrong-harness']:
 with tempfile.TemporaryDirectory(prefix='terminal-refusal-',dir=w) as temp:
  base=Path(temp);before=base/'terminal-before';after=base/'current-terminal-after'
  shutil.copytree(w/'terminal-before',before);shutil.copytree(w/'current-terminal-after',after)
  for name in ['capture-terminal.py','capture-current-terminal.py']:shutil.copyfile(w/name,base/name)
  binary=base/'current-selector-refresh/5231-selector-alternating/bin/packed';binary.parent.mkdir(parents=True);shutil.copyfile(w/'current-selector-refresh/5231-selector-alternating/bin/packed',binary)
  v.compare(before,after,reader)
  if case=='wrong-hash':
   status=read(after/'status.json');status['artifacts_sha256']['report.json']='0'*64;write(after/'status.json',status)
  elif case=='missing-artifact':
   status=read(after/'status.json');del status['artifacts_sha256']['report.json'];write(after/'status.json',status)
  elif case=='duplicate-sample':
   report=read(after/'report.json');report['rows'][1]=report['rows'][0];write(after/'report.json',report);resign(after)
  elif case.startswith('rehashed-'):
   field={'rehashed-wrong-probe':'terminal_node_probes','rehashed-storage-growth':'kernel_bytes','rehashed-allocation':'allocations'}.get(case)
   if field:row_change(after,lambda row:row.__setitem__(field,row[field]+1))
   else:row_change(after,lambda row:row.__setitem__('events',row['events'].replace('KernelEvent','AlteredEvent',1)))
   resign(after)
  else:
   report=read(after/'report.json')
   field,value={'native-word-lie':('native_word_bytes',4),'foreign-entrance':('measurement_entrance','different::fixture'),'wrong-harness':('harness_sha256','0'*64)}[case]
   report[field]=value;write(after/'report.json',report);resign(after)
  try:v.compare(before,after,reader)
  except (AssertionError,ValueError,KeyError) as e:results.append({'case':case,'refused':True,'reason':str(e)[:160]})
  else:raise AssertionError('corruption accepted: '+case)
(w/'current-terminal-negative.json').write_text(json.dumps({'all_refused':True,'cases':results},indent=2)+'\n');print(json.dumps(results))
