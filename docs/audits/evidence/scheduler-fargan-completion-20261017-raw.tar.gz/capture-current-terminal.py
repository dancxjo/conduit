import argparse, hashlib, json, os, platform, statistics, subprocess, struct
from pathlib import Path
if not __debug__:
    raise RuntimeError('evidence requires assertions')
p = argparse.ArgumentParser()
p.add_argument('label', choices=['after'])
a = p.parse_args()
root = Path('work/fargan-graph').resolve()
out = Path('work/current-terminal-after').resolve()
out.mkdir(exist_ok=False)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
source = git('rev-parse','HEAD')
assert not git('status','--porcelain')
build = Path('work/current-selector-refresh/5231-selector-alternating/packed.build.jsonl')
artifacts=[json.loads(s) for s in build.read_text().splitlines() if s.startswith('{') and json.loads(s).get('executable')]
assert len(artifacts)==1 and artifacts[0]['fresh'] is False
exe=Path('work/current-selector-refresh/5231-selector-alternating/bin/packed').resolve()
assert digest(exe)==json.loads(Path('work/current-selector-refresh/5231-selector-alternating/metadata.json').read_text())['builds']['packed']['executable_sha256']
exe_hash=digest(exe)
assert artifacts[0]['profile']['opt_level']=='3'
(out/'build.jsonl').write_bytes(build.read_bytes())
(out/'build.log').write_bytes(Path('work/current-selector-refresh/5231-selector-alternating/packed.build.log').read_bytes())
rows=[]
for run in range(3):
    assert source==git('rev-parse','HEAD') and not git('status','--porcelain') and digest(exe)==exe_hash
    command=['/usr/bin/time','-v','-o',str(out/f'process-{run}.resource.log'),str(exe),
      'scheduler::scan_characterization::terminal_completion::capture_completion_prefix','--exact','--ignored','--nocapture','--test-threads=1']
    with (out/f'process-{run}.stdout.log').open('w') as stdout, (out/f'process-{run}.stderr.log').open('w') as stderr:
        subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,check=True)
    text=(out/f'process-{run}.stdout.log').read_text()
    assert 'test result: ok. 1 passed; 0 failed' in text
    samples=[json.loads(s.split('TERMINAL_COMPLETION_ROW ',1)[1]) for s in text.splitlines() if 'TERMINAL_COMPLETION_ROW ' in s]
    assert len(samples)==32
    for sample in samples:
        assert sample['nodes'] in [1,8,32,256] and 0<=sample['trial']<8
        assert sample['allocations']==sample['reallocations']==0
        assert sample['terminal_node_probes']==(0 if sample['nodes'] >= 2*struct.calcsize('P') else 17*sample['nodes'])
        rows.append({'process':run,**sample})
assert source==git('rev-parse','HEAD') and not git('status','--porcelain')
summary=[]
for n in [1,8,32,256]:
    samples=[r for r in rows if r['nodes']==n]
    assert len(samples)==24
    means=[statistics.mean(r['elapsed_ns'] for r in samples if r['process']==process) for process in range(3)]
    assert len({r['events'] for r in samples})==1
    summary.append({'nodes':n,'process_mean_ns':means,'mean_ns':statistics.mean(means),'process_sd_ns':statistics.stdev(means)})
report={'measurement_schema':'conduit.terminal-prefix/reserved-count@1','native_word_bytes':struct.calcsize('P'),'measurement_entrance':'scheduler::scan_characterization::terminal_completion::capture_completion_prefix','source':source,'selector':'packed','optimized':True,'executable_sha256':exe_hash,'profile':artifacts[0]['profile'],
 'harness_sha256':digest(Path(__file__)),'rustc':subprocess.check_output(['rustc','-Vv'],cwd=root,text=True),
 'cpu_model':next(s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),
 'affinity':sorted(os.sched_getaffinity(0)),'system':platform.platform(),'rows':rows,'summary':summary,
 'limits':['Instrumented production-kernel completion fixture, not whole Plot/Plan/Host or FARGAN.',
 'Eight yielding Steps, one Await Step and eight Idle checks; final cancellation/retirement verified outside timing.',
 'Current reserved-word profile; tiny capacities retain original bounded prefix check.','Shared-host sequential observations against retained historical baseline; no causal speedup or calibrated regression gate.',
 'Whole-process CPU/RSS includes preparation, startup, assertions and serialization; not isolated Step CPU.',
 'Native 8 MiB diagnostic thread stack, not physical device proof.']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'status.json').write_text(json.dumps({'success':True,'source':source,'artifacts_sha256':{p.name:digest(p) for p in sorted(out.iterdir()) if p.is_file()}},indent=2)+'\n')
print(json.dumps(summary,indent=2))
