from pathlib import Path
import os,subprocess,time,json,hashlib,shutil,sys,importlib.util
sys.dont_write_bytecode=True
w=Path(__file__).resolve().parent;root=w/'fargan-graph';cwd=w/'fargan-boxed-before';target=root/'target'
before='a73aacf4da5969144e2eb86f5d75100f172c9f73';after='2bd626ddd13487c9977830151a8d9b8a9c15e594'
assert (w/'reserved-selector-refresh/verified-final.json').exists()
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
def git(path,*a):return subprocess.check_output(['git',*a],cwd=path,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze(path,source):
 assert not git(path,'status','--porcelain')
 subprocess.run(['git','switch','--detach',source],cwd=path,check=True)
 assert git(path,'rev-parse','HEAD')==source and not git(path,'status','--porcelain')
freeze(root,after)
commands=[('kernel-packed',['cargo','test','--locked','-p','conduit-kernel','--features','alloc,step-test-support','--tests']),('kernel-linear',['cargo','test','--locked','-p','conduit-kernel','--features','alloc,step-test-support,linear-ready-reference-test','--tests']),('kernel-no-default',['cargo','check','--locked','-p','conduit-kernel','--no-default-features']),('kernel-clippy',['cargo','clippy','--locked','-p','conduit-kernel','--features','alloc,step-test-support','--all-targets','--','-D','warnings']),('ai-tests',['cargo','test','--locked','-p','conduit-ai','--features','kernel-operation-owners,hosted-catalog-cache','--tests']),('conduitos-contracts',['cargo','test','--locked','-p','conduitos','--test','timing_profile','--test','pure_protocol_play'])]
for name,command in commands:
 print('start current '+name,flush=True)
 with (w/('current-after-'+name+'.log')).open('wb') as log:subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('passed current '+name,flush=True)
for mode,source in [('before',before),('after',after)]:
 freeze(cwd,source);output=w/('fargan-current-'+mode+'-01');command=['taskset','-c','1','cargo','xtask','prove','runtime-performance','--fargan-fixture',str(w/'fargan-development/fixture'),'--output',str(output),'--repetitions','2']
 print('start current FARGAN '+mode,flush=True)
 with (w/('fargan-current-'+mode+'-command.log')).open('wb') as log:subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 copy=w/('fargan-workers/current-'+mode);shutil.copyfile(target/'release/examples/fargan_performance',copy);copy.chmod(0o755)
 receipt={'source':source,'binary_sha256':sha(copy),'conformance_success':True,'capture':str(output),'compilation_path':str(cwd),'command':command}
 (w/('fargan-workers/current-'+mode+'-build.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print('captured current '+mode,flush=True)
spec=importlib.util.spec_from_file_location('verifier',w/'fargan-boxed-after/proof/performance/verify-fargan.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
initial=v.compare(v.verify(w/'fargan-current-before-01'),v.verify(w/'fargan-current-after-01'))
(w/'fargan-current-comparison.json').write_text(json.dumps(initial,indent=2)+'\n')
print('current initial ratio='+str(initial['ratios']['wall_ns']['after_over_before']),flush=True)
print('start current selector matrix',flush=True)
with (w/'current-selector-refresh/command.log').open('wb') as log:subprocess.run(['python3',str(w/'current-selector-refresh/capture-selector-alternating.py')],cwd=w.parent,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['python3',str(w/'fargan-boxed-after/proof/performance/verify-selector-pairs.py'),'--capture',str(w/'current-selector-refresh/5231-selector-alternating'),'--output',str(w/'current-selector-refresh/verified.json')],check=True)
print('current selector verified',flush=True)
config={'before':{'cwd':w/'fargan-review','source':before},'after':{'cwd':root,'source':after}};reports=[initial]
for pair in [1,2]:
 results={}
 for mode in (['after','before'] if pair%2 else ['before','after']):
  c=config[mode];worker=w/('fargan-workers/current-'+mode);receipt_path=w/('fargan-workers/current-'+mode+'-build.json');receipt=json.loads(receipt_path.read_text());source=c['source']
  assert git(c['cwd'],'rev-parse','HEAD')==source and not git(c['cwd'],'status','--porcelain')
  assert sha(worker)==receipt['binary_sha256']
  output=w/f'fargan-current-pair-{pair:02}-{mode}';output.mkdir();shutil.copyfile(receipt_path,output/'worker-build.json')
  for name in ['conformance.stdout.log','conformance.stderr.log']:shutil.copyfile(w/('fargan-current-'+mode+'-01')/name,output/name)
  command=['taskset','-c','1',str(worker),str(w/'fargan-development/fixture'),str(output),'2']
  print(f'start current pair={pair} mode={mode}',flush=True)
  with (output/'stdout.log').open('wb') as out,(output/'stderr.log').open('wb') as err:status=subprocess.run(command,cwd=c['cwd'],stdout=out,stderr=err)
  final=git(c['cwd'],'rev-parse','HEAD');clean=not git(c['cwd'],'status','--porcelain')
  report={'schema':'conduit.fargan-runtime-performance-command@1','git_sha':source,'final_git_sha':final,'source_custody_verified':final==source and clean,'conformance_success':receipt['conformance_success'],'worker_success':status.returncode==0,'worker_exit_code':status.returncode,'repetitions':2,'artifact_sha256':{str(p.relative_to(output)):sha(p) for p in output.rglob('*') if p.is_file()},'command':command,'prebuilt_worker_sha256':receipt['binary_sha256'],'proof_scope':'Refreshed development source, identical boxed preparation and model; prebuilt worker from supported xtask conformance/capture. Independent processes; no implementation substitution.'}
  (output/'status.json').write_text(json.dumps(report,indent=2)+'\n');results[mode]=v.verify(output)
  print(f'verified current pair={pair} mode={mode}',flush=True)
 comparison=v.compare(results['before'],results['after']);reports.append(comparison)
 (w/f'fargan-current-pair-{pair:02}-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
 print(f'current pair={pair} whole ratio={comparison["ratios"]["wall_ns"]["after_over_before"]}',flush=True)
(w/'fargan-current-process-comparisons.json').write_text(json.dumps(reports,indent=2)+'\n')
print('all current-source proof verified',flush=True)
