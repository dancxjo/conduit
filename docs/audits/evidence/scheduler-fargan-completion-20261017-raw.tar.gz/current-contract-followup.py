from pathlib import Path
import os,subprocess,time,json,hashlib,sys
sys.dont_write_bytecode=True
w=Path(__file__).resolve().parent;root=w/'fargan-graph';source='2bd626ddd13487c9977830151a8d9b8a9c15e594'
while Path('/proc/2344613/stat').exists() and Path('/proc/2344613/stat').read_text().split(') ')[1].split()[0]!='Z':time.sleep(5)
assert (w/'fargan-current-process-comparisons.json').exists(),'Current performance capture did not finish'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
print('start current terminal replay',flush=True)
with (w/'current-terminal-command.log').open('wb') as log:subprocess.run(['python3',str(w/'capture-current-terminal.py'),'after'],cwd=w.parent,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['python3',str(w/'verify-current-terminal.py'),'--before',str(w/'terminal-before'),'--after',str(w/'current-terminal-after'),'--reader',str(w/'fargan-boxed-after/proof/performance/verify-terminal-completion.py'),'--output',str(w/'current-terminal-comparison.json')],check=True)
print('verified current terminal replay; start supported timing profile',flush=True)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
command=['cargo','xtask','make','conduitos','timing-profile']
with (w/'current-timing-profile.log').open('wb') as log:subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
final=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();clean=not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip();assert final==source and clean
files=sorted((root/'architecture/kernel/src').rglob('*.rs'))+sorted((root/'targets/conduitos/src').rglob('*timing*.rs'))
receipt={'source':source,'final_source':final,'source_custody_verified':clean,'command':command,'success':True,'timing_log_sha256':hashlib.sha256((w/'current-timing-profile.log').read_bytes()).hexdigest(),'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'scope':'Supported deterministic-emulator timing proof on current scheduler source; no physical timing/preemption claim.'}
(w/'current-timing-profile-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('current supported timing profile passed',flush=True)
