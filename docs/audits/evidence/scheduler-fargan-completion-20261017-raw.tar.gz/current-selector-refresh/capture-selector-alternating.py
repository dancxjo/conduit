import hashlib,json,os,platform,shutil,statistics,subprocess,time,tomllib
from pathlib import Path
root=Path('work/fargan-graph').resolve();out=Path('work/current-selector-refresh/5231-selector-alternating').resolve();out.mkdir(exist_ok=False);(out/'bin').mkdir()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
source=git('rev-parse','HEAD')
def custody():assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
custody();cpu=json.loads(Path('work/5231-selector-cpu.json').read_text());os.sched_setaffinity(0,{cpu['selected_cpu']})
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_DEBUG='0',CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='true',CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS='false',RUSTUP_TOOLCHAIN=tomllib.loads((root/'rust-toolchain.toml').read_text())['toolchain']['channel'])
meta={'source':source,'cpu_selection':cpu,'affinity':sorted(os.sched_getaffinity(0)),'rustc':subprocess.check_output(['rustc','-Vv'],cwd=root,env=env,text=True),'system':platform.platform(),'cpu_model':next(s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),'harness_sha256':digest(Path(__file__)),'builds':{}}
for label in ['packed','linear']:
 custody()
 (out/f'{label}.clean.log').write_text('No cleanup: first build of this committed source/profile/feature combination; fresh=false is required below.\n')
 features='alloc,step-test-support'+(',linear-ready-reference-test' if label=='linear' else '')
 cmd=['cargo','test','--locked','--release','-p','conduit-kernel','--features',features,'--lib','--no-run','--message-format=json']
 with (out/f'{label}.build.jsonl').open('w') as stdout,(out/f'{label}.build.log').open('w') as stderr:subprocess.run(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr,check=True)
 artifacts=[json.loads(s) for s in (out/f'{label}.build.jsonl').read_text().splitlines() if s.startswith('{') and json.loads(s).get('executable')]
 assert len(artifacts)==1 and artifacts[0]['fresh'] is False and artifacts[0]['profile']['opt_level']=='3'
 exe=Path(artifacts[0]['executable']);target=out/'bin'/label;shutil.copy2(exe,target);assert digest(exe)==digest(target)
 meta['builds'][label]={'command':cmd,'profile':artifacts[0]['profile'],'executable_sha256':digest(target)}
assert meta['builds']['packed']['profile']==meta['builds']['linear']['profile']
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
test='scheduler::scan_characterization::capture_small_and_large_selector_replay'
allrows=[];replays={};times={};processes=[]
for pair in range(9):
 for label in (['packed','linear'] if pair%2==0 else ['linear','packed']):
  custody();exe=out/'bin'/label;assert digest(exe)==meta['builds'][label]['executable_sha256']
  stem=f'{pair}-{label}';cmd=['/usr/bin/time','-v','-o',str(out/(stem+'.resource.log')),str(exe),test,'--exact','--ignored','--nocapture','--test-threads=1']
  start=time.monotonic_ns()
  with (out/(stem+'.stdout.log')).open('w') as stdout,(out/(stem+'.stderr.log')).open('w') as stderr:subprocess.run(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr,check=True)
  processes.append({'pair':pair,'selector':label,'command':cmd,'process_wall_ns':time.monotonic_ns()-start})
  text=(out/(stem+'.stdout.log')).read_text();assert 'test result: ok. 1 passed; 0 failed' in text
  parsed={tag:[] for tag in ['SCHEDULER_SCAN_ROW','SCHEDULER_OVERHEAD_ROW','SCHEDULER_REPLAY_ROW']}
  for line in text.splitlines():
   for tag in parsed:
    if tag+' ' in line:parsed[tag].append(json.loads(line.split(tag+' ',1)[1]))
  assert all(len(v)==64 for v in parsed.values())
  for scan,overhead,replay in zip(*parsed.values()):
   key=(scan['active_nodes'],scan['sparse'],scan['trial']);assert key==(replay['active'],replay['sparse'],replay['trial'])
   assert replay['legacy']==(label=='linear')
   assert all(overhead[k]==0 for k in ['ingress_allocations','ingress_reallocations','step_allocations','step_reallocations','step_value_store_copy_bytes'])
   baseline={k:v for k,v in replay.items() if k!='legacy'}
   if key in replays:assert baseline==replays[key],('replay',pair,label,key)
   else:replays[key]=baseline
   allrows.append({'pair':pair,'selector':label,'scan':scan,'overhead':overhead})
  times[pair,label]={(n,s):statistics.mean(r['step_ns'] for r in parsed['SCHEDULER_SCAN_ROW'] if r['active_nodes']==n and r['sparse']==s) for n in [1,8,32,256] for s in [False,True]}
# Preserve exact non-selection work and all allocation/copy observations per matched sample.
indexed={(r['pair'],r['selector'],r['scan']['active_nodes'],r['scan']['sparse'],r['scan']['trial']):r for r in allrows}
assert len(indexed)==len(allrows)==1152
for pair in range(9):
 for n,s,t in replays:
  a=indexed[pair,'packed',n,s,t];b=indexed[pair,'linear',n,s,t];assert a['overhead']==b['overhead']
  ignored={'prepare_ns','step_ns','ready_nodes_scanned','ready_bytes_scanned','pending_slots_scanned'}
  assert {k:v for k,v in a['scan'].items() if k not in ignored}=={k:v for k,v in b['scan'].items() if k not in ignored}
summary=[]
for n in [1,8,32,256]:
 for sparse in [False,True]:
  values={label:[times[pair,label][n,sparse] for pair in range(9)] for label in ['packed','linear']}
  ratios=[values['packed'][i]/values['linear'][i] for i in range(9)]
  summary.append({'nodes':n,'sparse':sparse,'process_mean_fixture_advance_ns':values,'mean_ns':{k:statistics.mean(v) for k,v in values.items()},'sample_sd_ns':{k:statistics.stdev(v) for k,v in values.items()},'paired_packed_over_linear_ratios':ratios,'paired_ratio_mean':statistics.mean(ratios),'paired_ratio_range':[min(ratios),max(ratios)]})
custody()
for name,value in [('raw.json',allrows),('replays.json',list(replays.values())),('processes.json',processes),('summary.json',summary)]: (out/name).write_text(json.dumps(value,indent=2)+'\n')
status={'success':True,'source':source,'pairs':9,'raw_samples':1152,'exact_replay_parity':True,'allocation_copy_size_parity':True,'limits':['Same-source diagnostic legacy enumeration versus production packed selection, not original Boolean storage.','Existing instrumented native fixed-kernel byte fixture; not whole checked Host or FARGAN.','Single allowed CPU affinity is not exclusive; no governor/thermal/load control or calibrated timing-regression threshold.','Alternating process order reduces simple order drift but does not prove independent causal speedup or universal tiny-Host timing equivalence.','Preparation, startup, ingress and serialized evidence are outside fixture advance; resource logs cover entire process.'],'artifacts_sha256':{str(p.relative_to(out)):digest(p) for p in sorted(out.rglob('*')) if p.is_file()}}
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(summary,indent=2))
