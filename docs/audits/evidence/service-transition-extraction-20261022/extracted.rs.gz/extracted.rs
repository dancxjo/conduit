#![no_std]
use core::arch::global_asm;
mod gdt { pub const USER_DATA_SELECTOR:u16=0x33; pub const USER_CODE_SELECTOR:u16=0x2b; }
global_asm!(
    include_str!("entry_return.S"),
    user_data = const gdt::USER_DATA_SELECTOR,
    user_code = const gdt::USER_CODE_SELECTOR,
);
