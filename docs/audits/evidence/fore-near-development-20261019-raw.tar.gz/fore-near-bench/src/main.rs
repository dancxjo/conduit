use conduit_plot::{PortableExpressionProgram, PreparedPortableExpressionEvaluator};
use std::{alloc::{GlobalAlloc, Layout, System}, sync::atomic::{AtomicBool, AtomicUsize, Ordering}, time::Instant};
struct Counting;
static ACTIVE: AtomicBool = AtomicBool::new(false);
static ALLOCATIONS: AtomicUsize = AtomicUsize::new(0);
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 { if ACTIVE.load(Ordering::Relaxed) { ALLOCATIONS.fetch_add(1, Ordering::Relaxed); } System.alloc(l) }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 { if ACTIVE.load(Ordering::Relaxed) { ALLOCATIONS.fetch_add(1, Ordering::Relaxed); } System.alloc_zeroed(l) }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 { if ACTIVE.load(Ordering::Relaxed) { ALLOCATIONS.fetch_add(1, Ordering::Relaxed); } System.realloc(p,l,n) }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) { System.dealloc(p,l) }
}
#[global_allocator] static ALLOCATOR: Counting = Counting;
#[repr(C)] struct Timespec { seconds: i64, nanos: i64 }
extern "C" { fn clock_gettime(clock: i32, value: *mut Timespec) -> i32; }
fn cpu() -> u64 {
    let mut value = Timespec { seconds: 0, nanos: 0 };
    assert_eq!(unsafe { clock_gettime(3, &mut value) }, 0, "Linux thread CPU clock required");
    value.seconds as u64 * 1_000_000_000 + value.nanos as u64
}
fn begin() { ALLOCATIONS.store(0, Ordering::SeqCst); ACTIVE.store(true, Ordering::SeqCst); }
fn end() -> usize { ACTIVE.store(false, Ordering::SeqCst); ALLOCATIONS.load(Ordering::SeqCst) }
fn main() {
    let directory = std::env::args().nth(1).expect("fixture directory");
    let packet_hex = std::fs::read_to_string(format!("{directory}/packet.hex")).unwrap();
    let packet = packet_hex.trim().as_bytes().chunks_exact(2).map(|s| u8::from_str_radix(std::str::from_utf8(s).unwrap(),16).unwrap()).collect::<Vec<_>>();
    println!("profile,trial,preparation_wall_ns,preparation_cpu_ns,preparation_allocations,calls,warm_wall_ns,warm_cpu_ns,hot_allocations");
    for (label, file, calls) in [("structural-identity","plain.hex",1024), ("qualified-identity","qualified.hex",64)] {
        let text = std::fs::read_to_string(format!("{directory}/{file}")).unwrap();
        let program = PortableExpressionProgram::from_canonical_hex(text.trim()).unwrap();
        for trial in 0..32 {
            let wall = Instant::now(); let thread = cpu(); begin();
            let mut evaluator = PreparedPortableExpressionEvaluator::new(&program).unwrap();
            let preparation_allocations = end(); let preparation_cpu = cpu()-thread; let preparation_wall = wall.elapsed().as_nanos();
            assert_eq!(evaluator.evaluate(&packet).unwrap(), packet);
            let capacity = evaluator.output_capacity();
            let wall = Instant::now(); let thread = cpu(); begin();
            for _ in 0..calls { std::hint::black_box(evaluator.evaluate(std::hint::black_box(&packet)).unwrap()); }
            let hot_allocations = end(); let warm_cpu = cpu()-thread; let warm_wall = wall.elapsed().as_nanos();
            assert_eq!(hot_allocations,0); assert_eq!(evaluator.output_capacity(),capacity); assert_eq!(evaluator.output_bytes(),packet);
            println!("{label},{trial},{preparation_wall},{preparation_cpu},{preparation_allocations},{calls},{warm_wall},{warm_cpu},{hot_allocations}");
        }
    }
}
