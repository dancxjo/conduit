"""One normal PROFILE build and retained-image journey; no retries or relaxed bounds."""
import datetime,hashlib,json,os,pathlib,shutil,signal,subprocess,time,sys
ROOT=pathlib.Path(__file__).resolve().parent.parent
REPO=ROOT/'work/6267-review'
SOURCE='4cc7afae50ca1b591f0c077a9c4d0401af89ab82'
OWNER_ROOT=pathlib.Path('/home/dancxjo/Documents/Codex/2026-10-21/goal-find-the-first-available-github')
CACHE=OWNER_ROOT/'work/domain-6183-build-target'
MARKER=OWNER_ROOT/'work/6185-61b-cache-ownership.json'
OUT=ROOT/'work/6318-normal-product-proof'
SCRATCH=pathlib.Path('/dev/shm/conduit-6318-normal-proof-tmp')
sys.path.insert(0,str(OWNER_ROOT/'work'))
from tmp_quota_headroom import observation

def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],text=True).strip()
def digest(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def resources():return {'time':time.time(),'free_bytes':shutil.disk_usage(ROOT).free,'tmp_quota':observation(),'scratch_free_bytes':shutil.disk_usage(SCRATCH if SCRATCH.exists()else SCRATCH.parent).free}
def main():
 assert git('rev-parse','HEAD')==SOURCE and not git('status','--porcelain')
 assert git('ls-remote','origin','refs/heads/prep/6318-bounded-publication-20261023').split()[0]==SOURCE
 owner=json.loads(MARKER.read_text());assert owner['status'] in ('idle','released') and owner['cache']==str(CACHE),owner
 # Respect the prior owner's entire native proof, including QEMU, via marker.
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdigit()or int(proc.name)==os.getpid():continue
  try:
   for fd in (proc/'fd').iterdir():
    try:assert not os.readlink(fd).startswith(str(CACHE)),(proc.name,str(fd))
    except FileNotFoundError:pass
   command=(proc/'cmdline').read_bytes();exe=command.split(b'\0')[0]
   if b'cargo'in exe or b'rustc'in exe:
    assert str(CACHE).encode()not in command+(proc/'environ').read_bytes(),proc.name
   assert str(CACHE).encode()not in (proc/'maps').read_bytes(),proc.name
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 start=resources();assert start['free_bytes']>=4.5*2**30 and start['scratch_free_bytes']>=2**30 and start['tmp_quota']['remaining_bytes']>=128*2**20,start
 SCRATCH.mkdir(exist_ok=False)
 OUT.mkdir(exist_ok=False)
 marker={'owner':'root/6318-normal-proof','pid':os.getpid(),'cache':str(CACHE),'source':SOURCE,'status':'active'}
 MARKER.write_text(json.dumps(marker))
 env=os.environ.copy()
 for name in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CONDUITOS_BUILD_ID','CONDUITOS_IMAGE_ID','CONDUITOS_MAKE_RECORD']:env.pop(name,None)
 selected={'CARGO_TARGET_DIR':str(CACHE),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CONDUIT_CONDUITOS_TARGET_ROOT':str(OUT/'native'),'TMPDIR':str(SCRATCH)};env.update(selected)
 receipt={'source':SOURCE,'tree':git('rev-parse','HEAD^{tree}'),'status':'active','proof_class':'normal ProductHost freestanding-emulator','attempts_per_command':1,'previous_owner':owner,'environment':selected,'start_resources':start,'steps':[]}
 def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 commands=[['cargo','+stable','xtask','make','host','build','targets/conduitos/profiles/conduitos-native.host.conduit','--output',str(OUT/'host'),'--locked'],['cargo','+stable','xtask','make','host','verify',str(OUT/'host'),'--journey','--locked']]
 process=None
 try:
  for index,argv in enumerate(commands):
   row={'argv':argv,'started':time.time(),'samples':[]};receipt['steps'].append(row);log=OUT/f'{index}-command.log';save()
   with log.open('wb')as output:
    process=subprocess.Popen(argv,cwd=REPO,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=process.pid;save()
    while process.poll()is None:
     sample=resources();row['samples'].append(sample);save()
     if sample['free_bytes']<2*2**30 or sample['scratch_free_bytes']<128*2**20 or sample['tmp_quota']['remaining_bytes']<128*2**20:
      row['resource_stop']=sample;os.killpg(process.pid,signal.SIGTERM)
      try:process.wait(timeout=10)
      except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
      break
     try:process.wait(timeout=15)
     except subprocess.TimeoutExpired:pass
   row.update(exit_code=process.returncode,finished=time.time(),log_sha256=digest(log));save()
   if process.returncode:receipt['status']='failed-first-attempt';break
  else:receipt['status']='commands-passed-independent-artifact-review-pending'
 except BaseException as error:
  receipt['status']='runner-failure';receipt['runner_error']=repr(error)
  if process is not None and process.poll()is None:
   os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
  raise
 finally:
  receipt.update(finished=time.time(),source_unchanged=git('rev-parse','HEAD')==SOURCE,source_clean=not git('status','--porcelain'),end_resources=resources());save();MARKER.write_text(json.dumps({'owner':'root/6318-normal-proof','cache':str(CACHE),'status':'released','receipt':str(OUT/'receipt.json')}))
 return 0 if receipt['status']=='commands-passed-independent-artifact-review-pending'else 1
if __name__=='__main__':raise SystemExit(main())
