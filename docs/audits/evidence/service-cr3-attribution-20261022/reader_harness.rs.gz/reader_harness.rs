use std::fmt;
#[derive(Debug)]
pub struct ConduitosError {
    reason: &'static str,
    detail: String,
}

impl ConduitosError {
    fn refusal(reason: &'static str, detail: impl Into<String>) -> Self {
        const MAX_DETAIL_BYTES: usize = 512;
        let detail = detail.into();
        let end = detail
            .char_indices()
            .map(|(index, character)| index + character.len_utf8())
            .take_while(|end| *end <= MAX_DETAIL_BYTES)
            .last()
            .unwrap_or(0);
        Self {
            reason,
            detail: detail[..end].to_owned(),
        }
    }
}

impl fmt::Display for ConduitosError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "ConduitOS proof refusal [{}]: {}",
            self.reason, self.detail
        )
    }
}

impl std::error::Error for ConduitosError {}


mod ordinary_domain_proof {
#[path="/home/dancxjo/Documents/Codex/2026-10-21/goal-find-the-first-available-github/work/6183-cr3-attribution/targets/conduitos/make/xtask/ordinary_domain_proof/cr3.rs"]
mod cr3;
}
