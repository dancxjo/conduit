#[path="/home/dancxjo/Documents/Codex/2026-10-21/goal-find-the-first-available-github/work/6183-cr3-attribution/targets/conduitos/src/arch/x86_64/domain_transition/cr3_observation.rs"] mod snapshot;
