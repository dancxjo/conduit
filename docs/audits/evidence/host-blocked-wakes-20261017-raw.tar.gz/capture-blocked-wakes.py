import argparse, hashlib, json, os, platform, statistics, subprocess
from pathlib import Path
if not __debug__:
    raise RuntimeError('evidence requires assertions')
p=argparse.ArgumentParser()
p.add_argument('label',choices=['baseline','after'])
a=p.parse_args()
root=Path('work/conduit').resolve()
out=Path('work/blocked-wakes-'+a.label).resolve()
out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
source=git('rev-parse','HEAD')
assert not git('status','--porcelain')
build=Path('work/blocked-wakes-'+a.label+'-build.jsonl')
artifacts=[json.loads(s) for s in build.read_text().splitlines() if s.startswith('{') and json.loads(s).get('executable')]
assert len(artifacts)==1 and artifacts[0]['fresh'] is False
assert artifacts[0]['profile']['opt_level']=='3'
exe=Path(artifacts[0]['executable']); exe_hash=digest(exe)
(out/'build.jsonl').write_bytes(build.read_bytes())
(out/'build.log').write_bytes(Path('work/blocked-wakes-'+a.label+'-build.log').read_bytes())
rows=[]; replay=None
for run in range(3):
    assert source==git('rev-parse','HEAD') and not git('status','--porcelain') and digest(exe)==exe_hash
    command=['/usr/bin/time','-v','-o',str(out/f'process-{run}.resource.log'),str(exe),
      'scheduler::scan_characterization::blocked_wakes::input_wakes_of_host_blocked_nodes_are_characterized_without_running_backs','--exact','--nocapture','--test-threads=1']
    with (out/f'process-{run}.stdout.log').open('w') as stdout,(out/f'process-{run}.stderr.log').open('w') as stderr:
        subprocess.run(command,cwd=root,stdout=stdout,stderr=stderr,check=True)
    text=(out/f'process-{run}.stdout.log').read_text()
    assert 'test result: ok. 1 passed; 0 failed' in text
    def row(tag):
        items=[json.loads(s.split(tag+' ',1)[1]) for s in text.splitlines() if tag+' ' in s]
        assert len(items)==1
        return items[0]
    work=row('BLOCKED_WAKE_ROW'); current=row('BLOCKED_WAKE_REPLAY')
    assert work['nodes']==256 and work['idle_polls']==8
    assert work['allocations']==work['reallocations']==0
    expected=2048 if a.label=='baseline' else 0
    assert work['candidate_nodes']==work['pending_probes']==expected
    assert current['terminal']=='Cancelled' and current['values']==current['pending']==0
    assert replay is None or replay==current
    replay=current;rows.append(work)
assert source==git('rev-parse','HEAD') and not git('status','--porcelain')
report={'source':source,'selector':'packed','runs':3,'executable_sha256':exe_hash,'profile':artifacts[0]['profile'],
 'harness_sha256':digest(Path(__file__)),'rustc':subprocess.check_output(['rustc','-Vv'],cwd=root,text=True),
 'cpu_model':next(s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),
 'affinity':sorted(os.sched_getaffinity(0)),'system':platform.platform(),'rows':rows,'replay':replay,
 'summaries':{name:{'samples_ns':[r[name] for r in rows],'mean_ns':statistics.mean(r[name] for r in rows),'process_sd_ns':statistics.stdev(r[name] for r in rows)} for name in ['wake_ns','idle_ns']},
 'limits':['Instrumented native production-kernel Host blocking fixture, not whole checked Host/FARGAN throughput.',
 'Wake window includes real ingress, pressure refusal, values and mandatory Signs; idle window includes eight asserted Step calls.',
 'Independent-process samples on a shared uncontrolled host; descriptive, not a calibrated speedup/regression gate.',
 'CPU/RSS logs cover entire process including preparation, requests, completion/rearm, cancellation and serialization.',
 'Native 8 MiB diagnostic thread stack is not a constrained-device reservation.']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'status.json').write_text(json.dumps({'success':True,'source':source,'artifacts_sha256':{p.name:digest(p) for p in sorted(out.iterdir()) if p.is_file()}},indent=2)+'\n')
print(json.dumps(report['summaries'],indent=2))
