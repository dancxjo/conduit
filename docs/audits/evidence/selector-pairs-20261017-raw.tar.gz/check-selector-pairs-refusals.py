from pathlib import Path
import hashlib,importlib.util,json,shutil,tempfile
root=Path('work/conduit');spec=importlib.util.spec_from_file_location('pairs',root/'proof/performance/verify-selector-pairs.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=Path('work/5231-selector-alternating');cases=[]
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def rehash(folder,name):
 status=json.loads((folder/'status.json').read_text());status['artifacts_sha256'][name]=hashlib.sha256((folder/name).read_bytes()).hexdigest();write(folder/'status.json',status)
for case in ['wrong-artifact-hash','duplicate-raw-sample','rehashed-timing-disagrees-with-stdout','rehashed-altered-sign-replay']:
 with tempfile.TemporaryDirectory(dir='work') as temp:
  base=Path(temp);folder=base/'capture';shutil.copytree(original,folder);shutil.copy2('work/capture-selector-alternating.py',base/'capture-selector-alternating.py')
  if case=='wrong-artifact-hash':
   status=json.loads((folder/'status.json').read_text());status['artifacts_sha256']['raw.json']='0'*64;write(folder/'status.json',status)
  elif case in ['duplicate-raw-sample','rehashed-timing-disagrees-with-stdout']:
   raw=json.loads((folder/'raw.json').read_text())
   if case=='duplicate-raw-sample':raw[1]=raw[0]
   else:raw[0]['scan']['step_ns']+=1
   write(folder/'raw.json',raw);rehash(folder,'raw.json')
  else:
   name='0-packed.stdout.log';text=(folder/name).read_text();assert 'KernelEvent' in text;(folder/name).write_text(text.replace('KernelEvent','AlteredEvent',1));rehash(folder,name)
  try:module.verify(folder)
  except AssertionError as error:cases.append({'case':case,'refused':True,'reason':str(error)[:200]})
  else:raise AssertionError(('corruption accepted',case))
Path('work/5231-selector-alternating-negative.json').write_text(json.dumps({'all_refused':True,'cases':cases},indent=2)+'\n');print(cases)
